/* Демо-режим для проверки интерфейса без бэкенда: ui/index.html?mock=1
   Используется только для отладки вёрстки и скриншотов. */

(function () {
  if (!location.search.includes("mock=1")) return;

  const demo = new URLSearchParams(location.search).has("servers");
  const servers = [
    {
      name: "Mineblaze", ip: "mc.mineblaze.net", versions: "1.8 – 26.3",
      tag: "Выживание · мини-игры", color: "#ff8a3d",
      note: "Выживание, гриферский режим и мини-игры: BedWars, SkyWars, KitPvP и дуэли. Онлайн в среднем ~3 000 игроков.",
      avatar: "servers/mineblaze.png", hit: true, installed: false,
    },
  ];
  if (demo) {
    servers.push({
      name: "Hypixel", ip: "mc.hypixel.net", versions: "1.8 – 26.3",
      tag: "Мини-игры", color: "#f0b429", note: "Крупнейший международный сервер",
      avatar: "", hit: false, installed: true,
    });
  }

  const news = [
    { tag: "ОТКРЫТИЕ", date: "26.10.2026", title: "Full Launcher открыт для пользования", text: "Лаунчер полностью открыт: ставьте любую версию от 1.7.10 до 26.3, выбирайте Forge, Fabric, OptiFine — и запускайте в один клик. Никаких ключей и подписок, всё бесплатно.", cover: "news-cover.jpg", featured: true },
    { tag: "ОБНОВЛЕНИЕ", date: "26.10.2026", title: "Minecraft 26.3 уже в списке", text: "Список версий тянется напрямую из манифеста Mojang, поэтому новые релизы появляются в лаунчере в день выхода." },
    { tag: "МОДЫ", date: "26.10.2026", title: "Моды в один клик", text: "Каталог Modrinth внутри лаунчера: ищите моды под свою версию и модлоадер и ставьте их без браузера." },
    { tag: "СЕРВЕРЫ", date: "26.10.2026", title: "Свой сервер в списке", text: "Хотите видеть свой сервер в рекомендациях? Напишите @Azbu4ka в Telegram." },
    { tag: "JAVA", date: "26.10.2026", title: "Java ставится сама", text: "Лаунчер сам подбирает и скачивает официальный рантайм Mojang под версию игры — вручную ставить Java больше не нужно." },
  ];

  const ids = ["26.3", "26.2", "26.1.2", "26.1.1", "26.1", "1.21.11", "1.21.10", "1.21.9", "1.21.8", "1.21.7", "1.21.6", "1.21.5", "1.21.4", "1.21.3", "1.21.1", "1.21", "1.20.6", "1.20.4", "1.20.2", "1.20.1", "1.20", "1.19.4", "1.19.2", "1.18.2", "1.17.1", "1.16.5", "1.16.4", "1.15.2", "1.14.4", "1.13.2", "1.12.2", "1.12.1", "1.12", "1.11.2", "1.11", "1.10.2", "1.9.4", "1.9", "1.8.9", "1.8", "1.7.10"];
  const recommendation = new Set(["26.3", "1.21.8", "1.21.4", "1.20.1", "1.16.5", "1.12.2", "1.8.9", "1.7.10"]);
  const releases = ids.map((id, index) => ({
    id,
    type: "release",
    released: "2026-09-15".slice(0, 10),
    recommended: recommendation.has(id),
    idx: index,
  }));

  const modHits = [
    { id: "jei", slug: "jei", title: "Just Enough Items", description: "Просмотр всех рецептов и предметов прямо в игре — базовый мод для любой сборки.", author: "mezz", downloads: 312000000, icon: null, versions: ["1.21.4", "1.21.1", "1.20.1", "1.19.2", "1.18.2", "1.16.5", "1.12.2"], supports: true },
    { id: "journeymap", slug: "journeymap", title: "JourneyMap", description: "Карта мира в реальном времени, миникарта и точки интереса.", author: "techbrew", downloads: 148000000, icon: null, versions: ["1.21.4", "1.20.1", "1.19.2", "1.18.2", "1.16.5"], supports: true },
    { id: "mouse-tweaks", slug: "mouse-tweaks", title: "Mouse Tweaks", description: "Удобное перетаскивание предметов в инвентаре колесом и Shift.", author: "YaLTeR", downloads: 96000000, icon: null, versions: ["1.21.4", "1.21.1", "1.20.1", "1.19.2", "1.18.2", "1.16.5", "1.12.2", "1.7.10"], supports: true },
    { id: "jade", slug: "jade", title: "Jade", description: "Подсказка о блоке или сущности, на которую смотрит игрок.", author: "Snownee", downloads: 72000000, icon: null, versions: ["1.21.4", "1.20.1", "1.19.2", "1.18.2"], supports: true },
    { id: "sodium", slug: "sodium", title: "Sodium", description: "Мощная оптимизация рендера — только Fabric и NeoForge, для Forge сборки нет.", author: "jellysquid3", downloads: 210000000, icon: null, versions: ["1.21.4", "1.21.1", "1.20.1"], supports: false, availableLoaders: ["fabric", "neoforge"] },
    { id: "legacy-pack", slug: "legacy-pack", title: "Legacy Pack", description: "Старая сборка: существует только для 1.12.2 и 1.7.10.", author: "demo", downloads: 4200000, icon: null, versions: ["1.12.2", "1.7.10"], supports: false, availableLoaders: [] },
  ];

  const allMods = [];
  for (let i = 0; i < 45; i += 1) {
    const base = modHits[i % modHits.length];
    allMods.push(Object.assign({}, base, {
      id: i < modHits.length ? base.id : base.id + "-" + i,
      title: i < modHits.length ? base.title : base.title + " " + (i + 1),
    }));
  }

  const shaderHits = [
    { id: "complementary-reimagined", slug: "complementary-reimagined", title: "Complementary Shaders — Reimagined", description: "Тёплое освещение, мягкие тени и вода без артефактов — самый популярный шейдер-пак.", author: "EminGT", downloads: 84000000, icon: null, versions: ["26.3", "26.2", "1.21.4", "1.20.1"], supports: true },
    { id: "bsl-shaders", slug: "bsl-shaders", title: "BSL Shaders", description: "Классика: насыщенные цвета, красивые закаты и объёмный туман.", author: "CaptTatsu", downloads: 61000000, icon: null, versions: ["26.3", "26.2", "1.21.4", "1.20.1"], supports: true },
    { id: "sildurs-vibrant", slug: "sildurs-vibrant-shaders", title: "Sildur's Vibrant Shaders", description: "Гибкие настройки: от лёгкого варианта до тяжёлого с тенями и водой.", author: "Sildur", downloads: 47000000, icon: null, versions: ["1.21.4", "1.21.1", "1.20.1"], supports: true },
    { id: "complementary-unbound", slug: "complementary-unbound", title: "Complementary Shaders — Unbound", description: "Вариант с более холодной палитрой и агрессивными отражениями.", author: "EminGT", downloads: 32000000, icon: null, versions: ["26.3", "1.21.4"], supports: true },
    { id: "legacy-shader", slug: "legacy-shader", title: "Legacy Shader Pack", description: "Старый пак: существует только для 1.12.2 и 1.7.10.", author: "demo", downloads: 1900000, icon: null, versions: ["1.12.2", "1.7.10"], supports: false },
  ];

  const allShaders = [];
  for (let i = 0; i < 30; i += 1) {
    const base = shaderHits[i % shaderHits.length];
    allShaders.push(Object.assign({}, base, {
      id: i < shaderHits.length ? base.id : base.id + "-" + i,
      title: i < shaderHits.length ? base.title : base.title + " " + (i + 1),
    }));
  }

  const qs = new URLSearchParams(location.search);
  const config = {
    nickname: "Steve", version: "1.20.1",
    loader: qs.get("loader") || (qs.has("shaders") ? "forgeoptifine" : "forge"),
    loader_version: "47.4.28",
    ram: 4096, width: 925, height: 530, java_path: "", close_on_launch: false,
  };

  const api = {
    get_config: async () => ({ ok: true, config, nicknameValid: true, gameRoot: "C:\\Users\\loner\\AppData\\Roaming\\FullLauncher" }),
    rpc_status: async () => ({ state: "connected", detail: "Подключено как loner", connected: true, enabled: true, clientId: "1564259805990756382" }),
    set_rpc_enabled: async (enabled) => ({ state: enabled ? "connected" : "disabled", detail: "", connected: !!enabled, enabled: !!enabled, clientId: "1564259805990756382" }),
    bootstrap: async () => ({
      ok: true, error: null, appVersion: "1.0.0", latest: "26.3", config,
      nicknameValid: true, gameRoot: "C:\\Users\\loner\\AppData\\Roaming\\FullLauncher",
      modsDir: "C:\\Users\\loner\\AppData\\Roaming\\FullLauncher\\mods",
      optifineDir: "C:\\Users\\loner\\AppData\\Roaming\\FullLauncher\\optifine",
      servers, news, installed: [], java: [{ path: "java", version: 8, source: "system", label: "Java 8" }, { path: "java21", version: 21, source: "runtime", label: "Java 21" }],
      javaOk: true, totalReleases: releases.length,
    }),
    versions: async () => ({ ok: true, releases, latest: "26.3" }),
    loaders_for: async (version) => {
      const optifineOk = version !== "26.3";
      return {
        ok: true,
        fabric: ["0.16.9", "0.16.5", "0.15.11"],
        forge: ["47.4.28", "47.2.20", "47.1.3"],
        optifine: false,
        optifineFile: null,
        optifineSupported: optifineOk,
        optifineChecked: true,
        optifineLatest: "26.2",
        forgeOptifineSupported: optifineOk,
        forgeOptifineReason: optifineOk ? null : `OptiFine нет под ${version} (последняя — 26.2)`,
      };
    },
    set_config: async (patch) => ({ ok: true, config: Object.assign(config, JSON.parse(patch)), nicknameValid: true }),
    poll: async () => [],
    play: async () => ({ ok: false, error: "Демо-режим: запуск отключён" }),
    cancel: async () => ({ ok: false }),
    mods_search: async (payload) => {
      const req = JSON.parse(payload || "{}");
      const perPage = req.perPage || 21;
      const page = Math.max(1, req.page || 1);
      const offset = (page - 1) * perPage;
      const source = req.kind === "shader" ? allShaders : allMods;
      const slice = source.slice(offset, offset + perPage);
      return {
        available: true, error: null, hits: slice, installed: [],
        loader: config.loader, version: config.version, kind: req.kind || "mod",
        page, pages: Math.max(1, Math.ceil(source.length / perPage)),
        perPage, total: source.length,
        matching: slice.filter((m) => m.supports).length,
        checked: 0,
      };
    },
    mods_installed: async (kind) => (kind === "shader"
      ? [{ file: "ComplementaryReimagined_r5.3.zip", size: 3000 }]
      : [{ file: "jei-1.20.1-forge-15.20.0.106.jar", size: 1000 }, { file: "journeymap-1.20.1-5.9.18.jar", size: 2000 }]),
    mod_install: async () => ({ ok: false, error: "Демо-режим" }),
    mod_remove: async () => ({ ok: false }),
    add_server: async (name, ip) => {
      const found = servers.find((s) => s.ip === ip);
      if (found) found.installed = true;
      else servers.push({ name, ip, tag: "Сервер", color: "#8b5cf6", note: "", installed: true });
      return { ok: true, added: true, already: false, total: servers.length, servers };
    },
    remove_server: async () => ({ ok: true, servers }),
    open_folder: async () => ({ ok: true, path: "" }),    open_url: async () => ({ ok: true }),
    java_list: async () => ({ ok: true, javas: [] }),
    clear_cache: async () => ({ ok: true }),
    installed_versions: async () => ([{ id: "1.20.1" }]),
    minimize: async () => ({ ok: true }),
    toggle_maximize: async () => ({ ok: true }),
    close: async () => ({ ok: true }),
    diag: async () => ({ ok: true }),
  };

  window.pywebview = { api };

  window.addEventListener("DOMContentLoaded", () => {
    const q = new URLSearchParams(location.search);
    if (q.get("page")) setTimeout(() => setPage(q.get("page")), 1500);
    if (q.get("modal")) setTimeout(() => openVersionModal(), 1700);
    if (q.get("version")) setTimeout(() => openVersionModal(q.get("version")), 1700);
    if (q.get("overlay")) {
      setTimeout(() => {
        showOverlay("Запускаю 1.20.1 · Forge", "Скачиваю библиотеки Forge…");
        setOverlayProgress(64, "132 из 287 файлов", "4.2 МБ/с", "Скачиваю библиотеки Forge…");
      }, 1700);
    }
    if (q.get("loaders")) setTimeout(() => { const m = document.querySelector('[data-loader="forge"]'); if (m) m.click(); }, 2100);
  });
})();
