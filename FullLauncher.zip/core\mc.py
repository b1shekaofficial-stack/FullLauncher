"""Ядро Minecraft: манифест версий, библиотеки, нативы, assets, сборка команды запуска."""

import hashlib
import json
import os
import platform
import re
import shutil
import sys
import time
import urllib.parse
import uuid
import zipfile

from . import net

MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
RESOURCE_URL = "https://resources.download.minecraft.net"
LIBRARY_BASE = "https://libraries.minecraft.net"

OS_NAME = {"win32": "windows", "cygwin": "windows", "darwin": "osx"}.get(sys.platform, "linux")
_MACHINE = (platform.machine() or "").lower()
ARCH = "x86_64" if (sys.maxsize > 2 ** 32 or "64" in _MACHINE) else "x86"
ARCH_ALIASES = {"x86_64", "x64", "amd64", "arm64"}

MIN_OLDEST = "1.7.10"


def maven_path(name):
    parts = name.split(":")
    if len(parts) < 3:
        return None
    group, artifact, version = parts[0], parts[1], parts[2]
    classifier = parts[3] if len(parts) > 3 else None
    ext = parts[4] if len(parts) > 4 else "jar"
    filename = "%s-%s%s.%s" % (artifact, version, ("-" + classifier) if classifier else "", ext)
    return "%s/%s/%s/%s" % (group.replace(".", "/"), artifact, version, filename)


def _os_matches(os_rule):
    if "name" in os_rule and os_rule["name"] != OS_NAME:
        return False
    if "arch" in os_rule:
        want = str(os_rule["arch"]).lower()
        if want in ("x86", "i386") and ARCH != "x86":
            return False
        if want in ARCH_ALIASES and ARCH not in ARCH_ALIASES:
            return False
    if "version" in os_rule:
        try:
            if not re.search(os_rule["version"], platform.version() or ""):
                return False
        except re.error:
            return True
    return True


def rule_matches(rule, features=None):
    os_rule = rule.get("os") or {}
    if os_rule and not _os_matches(os_rule):
        return False
    rule_features = rule.get("features") or {}
    if rule_features:
        state = features or {}
        for key, value in rule_features.items():
            if bool(state.get(key)) != bool(value):
                return False
    return True


def is_allowed(rules, features=None):
    if not rules:
        return True
    allowed = False
    for rule in rules:
        if rule_matches(rule, features):
            allowed = rule.get("action", "allow") == "allow"
    return allowed


def native_classifier(lib):
    natives = lib.get("natives")
    if not natives:
        return None
    key = natives.get(OS_NAME)
    if not key:
        return None
    return key.replace("${arch}", "64" if ARCH != "x86" else "32")


def library_entry(lib):
    downloads = lib.get("downloads") or {}
    artifact = downloads.get("artifact")
    if artifact and artifact.get("path"):
        # У некоторых библиотек (например, пропатченный forge-…-client.jar)
        # url пустой: файл создаёт установщик локально.
        return {
            "path": artifact.get("path"),
            "url": artifact.get("url") or "",
            "sha1": artifact.get("sha1"),
            "size": artifact.get("size"),
        }
    if "downloads" in lib:
        return None
    name = lib.get("name")
    if not name:
        return None
    path = maven_path(name)
    if not path:
        return None
    base = (lib.get("url") or LIBRARY_BASE).rstrip("/")
    return {"path": path, "url": base + "/" + path, "sha1": None, "size": None}


def classify_name(name):
    parts = (name or "").split(":")
    if len(parts) >= 2:
        return parts[0] + ":" + parts[1]
    return name or ""


def library_key(lib):
    """Ключ дедупликации: группа, артефакт, классификатор и расширение.

    Без классификатора forge-…-universal и forge-…-client считались бы одним
    артефактом, и пропатченный client.jar терялся.
    """
    parts = (lib.get("name") or "").split(":")
    if len(parts) < 3:
        return (lib.get("name") or "") + "|" + str(lib.get("natives") or "")
    group, artifact = parts[0], parts[1]
    classifier = parts[3] if len(parts) > 3 else ""
    extension = parts[4] if len(parts) > 4 else "jar"
    native = native_classifier(lib) or ""
    return "%s:%s:%s:%s|%s" % (group, artifact, classifier, extension, native)


def merge_versions(parent, child):
    """Сливает дочерний профиль с родительским (inheritsFrom)."""
    merged = json.loads(json.dumps(parent))
    for key, value in child.items():
        if key in ("libraries", "arguments"):
            continue
        if key in ("downloads", "assetIndex", "javaVersion") and not value:
            continue
        merged[key] = value

    libs = []
    seen = set()
    for lib in list(child.get("libraries") or []) + list(parent.get("libraries") or []):
        if not is_allowed(lib.get("rules")):
            continue
        key = library_key(lib)
        if key in seen:
            continue
        seen.add(key)
        libs.append(lib)
    merged["libraries"] = libs

    if "arguments" in child or "arguments" in parent:
        cargs = child.get("arguments") or {}
        pargs = parent.get("arguments") or {}
        merged["arguments"] = {
            "game": list(cargs.get("game") or []) + list(pargs.get("game") or []),
            "jvm": list(cargs.get("jvm") or []) + list(pargs.get("jvm") or []),
        }
        merged.pop("minecraftArguments", None)
    return merged


def offline_uuid(nickname):
    digest = bytearray(hashlib.md5(("OfflinePlayer:" + nickname).encode("utf-8")).digest())
    digest[6] = (digest[6] & 0x0F) | 0x30
    digest[8] = (digest[8] & 0x3F) | 0x80
    return str(uuid.UUID(bytes=bytes(digest)))


def _version_key(version_id):
    parts = re.findall(r"\d+", version_id)
    return tuple(int(p) for p in parts[:3]) if parts else (0,)


class Game:
    def __init__(self, root):
        self.root = root
        self.versions_dir = os.path.join(root, "versions")
        self.libraries_dir = os.path.join(root, "libraries")
        self.assets_dir = os.path.join(root, "assets")
        self.mods_dir = os.path.join(root, "mods")
        self.shaderpacks_dir = os.path.join(root, "shaderpacks")
        self.runtime_dir = os.path.join(root, "runtime")
        self.cache_dir = os.path.join(root, "cache")
        self._manifest = None
        self._manifest_at = 0.0
        self._json_cache = {}

    # ---------- служебное ----------

    def ensure_dirs(self):
        for path in (self.root, self.versions_dir, self.libraries_dir,
                     os.path.join(self.assets_dir, "indexes"),
                     os.path.join(self.assets_dir, "objects"),
                     os.path.join(self.assets_dir, "log_configs"),
                     self.mods_dir, self.shaderpacks_dir, self.runtime_dir, self.cache_dir):
            os.makedirs(path, exist_ok=True)

    def manifest(self, force=False):
        cache_file = os.path.join(self.cache_dir, "version_manifest_v2.json")
        if not force:
            if self._manifest and time.time() - self._manifest_at < 1800:
                return self._manifest
            if os.path.exists(cache_file) and time.time() - os.path.getmtime(cache_file) < 3600:
                try:
                    with open(cache_file, "r", encoding="utf-8") as f:
                        self._manifest = json.load(f)
                    self._manifest_at = time.time()
                    return self._manifest
                except (OSError, ValueError):
                    pass
        data = net.get_json(MANIFEST_URL)
        self._manifest = data
        self._manifest_at = time.time()
        os.makedirs(self.cache_dir, exist_ok=True)
        try:
            with open(cache_file, "w", encoding="utf-8") as f:
                json.dump(data, f)
        except OSError:
            pass
        return data

    def releases(self):
        """Все релизы от 1.7.10 до актуального, новые сначала."""
        versions = self.manifest().get("versions") or []
        releases = [v for v in versions if v.get("type") == "release"]
        ids = [v["id"] for v in releases]
        oldest = None
        for idx, vid in enumerate(ids):
            if vid == MIN_OLDEST:
                oldest = idx
                break
        if oldest is None:
            oldest = len(ids)
            for idx, vid in enumerate(ids):
                if _version_key(vid) >= _version_key(MIN_OLDEST):
                    oldest = idx
        return releases[:oldest + 1]

    def version_index(self):
        return {v["id"]: v for v in self.manifest().get("versions") or []}

    def version_json(self, version_id, force=False):
        if not force and version_id in self._json_cache:
            return self._json_cache[version_id]
        local = os.path.join(self.versions_dir, version_id, version_id + ".json")
        if os.path.exists(local) and not force:
            try:
                with open(local, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self._json_cache[version_id] = data
                return data
            except (OSError, ValueError):
                pass
        meta = self.version_index().get(version_id)
        if not meta:
            raise RuntimeError("Версия %s не найдена в манифесте Mojang" % version_id)
        data = net.get_json(meta["url"])
        os.makedirs(os.path.dirname(local), exist_ok=True)
        with open(local, "w", encoding="utf-8") as f:
            json.dump(data, f)
        self._json_cache[version_id] = data
        return data

    def root_id(self, version_id):
        current = version_id
        for _ in range(6):
            data = self.version_json(current)
            parent = data.get("inheritsFrom")
            if not parent:
                return data.get("jar") or current
            current = parent
        return current

    def merged(self, version_id, depth=0):
        data = self.version_json(version_id)
        parent_id = data.get("inheritsFrom")
        if parent_id and depth < 6:
            parent = self.merged(parent_id, depth + 1)
            merged = merge_versions(parent, data)
            merged["id"] = version_id
            return merged
        merged = json.loads(json.dumps(data))
        merged["id"] = version_id
        return merged

    def installed_versions(self):
        found = []
        if not os.path.isdir(self.versions_dir):
            return found
        for name in os.listdir(self.versions_dir):
            if os.path.exists(os.path.join(self.versions_dir, name, name + ".json")):
                found.append(name)
        return found

    # ---------- загрузки ----------

    def ensure_client_jar(self, version_id, progress=None):
        root = self.root_id(version_id)
        data = self.version_json(root)
        client = (data.get("downloads") or {}).get("client")
        dest = os.path.join(self.versions_dir, root, root + ".jar")
        if not client or not client.get("url"):
            return dest if os.path.exists(dest) else None
        if progress:
            progress.plan(1, client.get("size") or 0)
        errors = net.download_many([{
            "url": client["url"], "dest": dest,
            "sha1": client.get("sha1"), "size": client.get("size"),
        }], progress, threads=1)
        if errors:
            raise RuntimeError("Клиент Minecraft не скачался: " + errors[0])
        return dest

    def install_libraries(self, merged, progress=None):
        items = []
        for lib in merged.get("libraries") or []:
            if not is_allowed(lib.get("rules")):
                continue
            entry = library_entry(lib)
            if entry:
                dest = os.path.join(self.libraries_dir, entry["path"].replace("/", os.sep))
                if entry["url"]:
                    items.append({
                        "url": entry["url"],
                        "dest": dest,
                        "sha1": entry.get("sha1"),
                        "size": entry.get("size"),
                    })
                elif not os.path.exists(dest):
                    raise RuntimeError(
                        "Не хватает локального файла библиотеки %s. Переустановите загрузчик "
                        "(Forge) — установщик создаёт этот файл сам." % os.path.basename(dest))
            classifier = native_classifier(lib)
            if classifier:
                extra = (lib.get("downloads") or {}).get("classifiers", {}).get(classifier)
                if extra and extra.get("url"):
                    items.append({
                        "url": extra["url"],
                        "dest": os.path.join(self.libraries_dir, extra["path"].replace("/", os.sep)),
                        "sha1": extra.get("sha1"),
                        "size": extra.get("size"),
                    })
        if progress:
            progress.plan(len(items), sum(i.get("size") or 0 for i in items))
        errors = net.download_many(items, progress)
        if errors:
            raise RuntimeError("Библиотеки не скачались: " + errors[0])
        return items

    def extract_natives(self, merged, version_id, progress=None):
        natives_dir = os.path.join(self.versions_dir, version_id, "natives")
        os.makedirs(natives_dir, exist_ok=True)
        jars = []
        for lib in merged.get("libraries") or []:
            if not is_allowed(lib.get("rules")):
                continue
            classifier = native_classifier(lib)
            if classifier:
                extra = (lib.get("downloads") or {}).get("classifiers", {}).get(classifier)
                if extra and extra.get("path"):
                    jars.append((extra["path"], (lib.get("extract") or {}).get("exclude") or ["META-INF/"]))
            elif "natives" in (lib.get("name") or ""):
                entry = library_entry(lib)
                if entry:
                    jars.append((entry["path"], ["META-INF/"]))
        for rel_path, exclude in jars:
            jar = os.path.join(self.libraries_dir, rel_path.replace("/", os.sep))
            if not os.path.exists(jar):
                continue
            try:
                with zipfile.ZipFile(jar) as zf:
                    for info in zf.infolist():
                        name = info.filename
                        if name.endswith("/"):
                            continue
                        if any(name.startswith(prefix) for prefix in exclude):
                            continue
                        if not name.lower().endswith((".dll", ".so", ".dylib", ".jnilib")):
                            continue
                        target = os.path.join(natives_dir, os.path.basename(name))
                        with zf.open(info) as src, open(target, "wb") as dst:
                            shutil.copyfileobj(src, dst)
            except (OSError, zipfile.BadZipFile):
                continue
        return natives_dir

    def ensure_assets(self, merged, progress=None):
        index_meta = merged.get("assetIndex")
        if not index_meta or not index_meta.get("url"):
            return None
        index_id = index_meta.get("id") or "legacy"
        index_path = os.path.join(self.assets_dir, "indexes", index_id + ".json")
        if not os.path.exists(index_path):
            if progress:
                progress.plan(1, index_meta.get("size") or 0)
            errors = net.download_many([{
                "url": index_meta["url"], "dest": index_path,
                "sha1": index_meta.get("sha1"), "size": index_meta.get("size"),
            }], progress, threads=1)
            if errors:
                raise RuntimeError("Индекс ресурсов не скачался: " + errors[0])
        with open(index_path, "r", encoding="utf-8") as f:
            index = json.load(f)
        objects = index.get("objects") or {}
        items = []
        for _name, obj in objects.items():
            digest = obj.get("hash")
            if not digest:
                continue
            items.append({
                "url": "%s/%s/%s" % (RESOURCE_URL, digest[:2], digest),
                "dest": os.path.join(self.assets_dir, "objects", digest[:2], digest),
                "sha1": digest,
                "size": obj.get("size") or 0,
            })
        if progress:
            progress.set_stage("assets", "Ресурсы: %d файлов" % len(items))
            progress.plan(len(items), sum(i["size"] for i in items))
        errors = net.download_many(items, progress, threads=16)
        if errors:
            raise RuntimeError("Ресурсы не скачались: " + errors[0])
        if index.get("virtual") or index.get("map_to_resources"):
            self._materialize_assets(index_id, index)
        return index_id

    def _materialize_assets(self, index_id, index):
        base = os.path.join(self.assets_dir, "virtual" if index.get("virtual") else "resources", index_id)
        for name, obj in (index.get("objects") or {}).items():
            digest = obj.get("hash")
            if not digest:
                continue
            src = os.path.join(self.assets_dir, "objects", digest[:2], digest)
            dst = os.path.join(base, name.replace("/", os.sep))
            if os.path.exists(dst) or not os.path.exists(src):
                continue
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(src, dst)

    def ensure_log_config(self, merged, progress=None):
        client = (merged.get("logging") or {}).get("client")
        if not client or not client.get("file"):
            return None
        meta = client["file"]
        dest = os.path.join(self.assets_dir, "log_configs", meta.get("id") or "client.xml")
        if progress:
            progress.plan(1, meta.get("size") or 0)
        net.download_many([{
            "url": meta["url"], "dest": dest,
            "sha1": meta.get("sha1"), "size": meta.get("size"),
        }], progress, threads=1)
        return dest, client.get("argument")

    def install(self, version_id, progress=None):
        """Полная установка версии (ваниль + модификации из профиля)."""
        self.ensure_dirs()
        merged = self.merged(version_id)
        root = self.root_id(version_id)
        if progress:
            progress.set_stage("client", "Клиент Minecraft %s" % root)
        jar = self.ensure_client_jar(version_id, progress)
        if progress:
            progress.set_stage("libraries", "Библиотеки")
        self.install_libraries(merged, progress)
        if progress:
            progress.set_stage("natives", "Распаковка нативов")
        natives_dir = self.extract_natives(merged, version_id, progress)
        self.ensure_assets(merged, progress)
        log_conf = self.ensure_log_config(merged, progress)
        return {
            "merged": merged,
            "jar": jar,
            "natives": natives_dir,
            "root": root,
            "log": log_conf,
        }

    # ---------- запуск ----------

    def classpath(self, merged, jar):
        paths = []
        seen = set()
        for lib in merged.get("libraries") or []:
            if not is_allowed(lib.get("rules")):
                continue
            entry = library_entry(lib)
            if not entry:
                continue
            path = os.path.join(self.libraries_dir, entry["path"].replace("/", os.sep))
            if path in seen or not os.path.exists(path):
                continue
            seen.add(path)
            paths.append(path)
        if jar and os.path.exists(jar) and jar not in seen:
            paths.append(jar)
        return os.pathsep.join(paths)

    def build_command(self, merged, opts):
        nickname = opts["nickname"]
        ram = int(opts.get("ram") or 2048)
        game_dir = opts["game_dir"]
        natives_dir = opts["natives_dir"]
        asset_index = opts.get("asset_index") or "legacy"
        log_conf = opts.get("log_conf")

        values = {
            "auth_player_name": nickname,
            "version_name": merged.get("id") or opts.get("version_name") or "full-launcher",
            "game_directory": game_dir,
            "assets_root": self.assets_dir,
            "game_assets": os.path.join(self.assets_dir, "virtual", "legacy"),
            "assets_index_name": asset_index,
            "auth_uuid": opts.get("uuid") or offline_uuid(nickname),
            "auth_access_token": opts.get("token") or "0",
            "auth_session": opts.get("token") or "0",
            "clientid": "",
            "auth_xuid": "",
            "user_type": "legacy",
            "version_type": merged.get("type") or "release",
            "user_properties": "{}",
            "natives_directory": natives_dir,
            "launcher_name": "FullLauncher",
            "launcher_version": opts.get("launcher_version") or "1.0.0",
            "classpath": opts["classpath"],
            "classpath_separator": os.pathsep,
            "library_directory": self.libraries_dir,
            "resolution_width": str(opts.get("width") or 925),
            "resolution_height": str(opts.get("height") or 530),
        }

        def sub(text):
            if not isinstance(text, str):
                return text
            for key, value in values.items():
                text = text.replace("${%s}" % key, str(value))
            return text

        cmd = [opts["java"]]
        if merged.get("arguments", {}).get("jvm"):
            for arg in merged["arguments"]["jvm"]:
                if isinstance(arg, str):
                    cmd.append(sub(arg))
                elif isinstance(arg, dict):
                    if not is_allowed(arg.get("rules")):
                        continue
                    if isinstance(arg.get("value"), list):
                        cmd.extend(sub(v) for v in arg["value"])
                    elif arg.get("value") is not None:
                        cmd.append(sub(arg["value"]))
        else:
            cmd.extend([
                "-Djava.library.path=%s" % natives_dir,
                "-Dminecraft.launcher.brand=FullLauncher",
                "-Dminecraft.launcher.version=%s" % (opts.get("launcher_version") or "1.0.0"),
                "-cp", values["classpath"],
            ])

        cmd.insert(1, "-Xmx%dM" % ram)
        cmd.insert(2, "-Xms%dM" % max(512, min(ram, 4096)))
        if log_conf and log_conf[1]:
            cmd.append(sub(log_conf[1].replace("${path}", log_conf[0])))

        cmd.append(merged.get("mainClass") or "net.minecraft.client.main.Main")

        legacy_args = merged.get("minecraftArguments")
        if legacy_args:
            for token in legacy_args.split(" "):
                if token:
                    cmd.append(sub(token))
        else:
            for arg in merged.get("arguments", {}).get("game") or []:
                if isinstance(arg, str):
                    cmd.append(sub(arg))
                elif isinstance(arg, dict):
                    if not is_allowed(arg.get("rules")):
                        continue
                    if isinstance(arg.get("value"), list):
                        cmd.extend(sub(v) for v in arg["value"])
                    elif arg.get("value") is not None:
                        cmd.append(sub(arg["value"]))
        return cmd
