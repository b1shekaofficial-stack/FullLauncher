"""Модлоадеры: Fabric, Forge, ForgeOptiFine, OptiFine."""

import glob
import json
import os
import re
import shutil
import subprocess
import threading
import time
import xml.etree.ElementTree as ET

from . import net, mc

FABRIC_META = "https://meta.fabricmc.net/v2"
FORGE_MAVEN = "https://maven.minecraftforge.net/net/minecraftforge/forge"
FORGE_METADATA_URL = FORGE_MAVEN + "/maven-metadata.xml"
CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0

_fabric_cache = {}
_forge_cache = {}

INSTALLER_LABEL = {
    "vanilla": "Vanilla",
    "fabric": "Fabric",
    "forge": "Forge",
    "forgeoptifine": "Forge + OptiFine",
    "optifine": "OptiFine",
}


# ---------- Fabric ----------

def fabric_versions(mc_id, force=False):
    if not force and mc_id in _fabric_cache:
        return _fabric_cache[mc_id]
    try:
        data = net.get_json("%s/versions/loader/%s" % (FABRIC_META, net.quote(mc_id)))
    except Exception:  # noqa: BLE001
        data = []
    versions = []
    for item in data:
        loader = item.get("loader") or {}
        version = loader.get("version")
        if not version:
            continue
        versions.append({"version": version, "stable": bool(loader.get("stable", True))})
    _fabric_cache[mc_id] = versions
    return versions


def latest_fabric(mc_id):
    versions = fabric_versions(mc_id)
    if not versions:
        return None
    for item in versions:
        if item["stable"]:
            return item["version"]
    return versions[0]["version"]


def install_fabric(game, mc_id, loader_version, progress=None):
    loader_version = loader_version or latest_fabric(mc_id)
    if not loader_version:
        raise RuntimeError("Fabric пока не поддерживает Minecraft %s" % mc_id)
    if progress:
        progress.set_stage("loader", "Установка Fabric %s" % loader_version)
    profile = net.get_json("%s/versions/loader/%s/%s/profile/json"
                           % (FABRIC_META, net.quote(mc_id), net.quote(loader_version)))
    profile.setdefault("inheritsFrom", mc_id)
    version_id = profile.get("id") or "fabric-loader-%s-%s" % (loader_version, mc_id)
    profile["id"] = version_id
    folder = os.path.join(game.versions_dir, version_id)
    os.makedirs(folder, exist_ok=True)
    with open(os.path.join(folder, version_id + ".json"), "w", encoding="utf-8") as f:
        json.dump(profile, f, indent=2)
    game._json_cache.pop(version_id, None)
    return version_id


# ---------- Forge ----------

def forge_versions(mc_id, force=False):
    if not force and mc_id in _forge_cache:
        return _forge_cache[mc_id]
    try:
        xml_text = net.get_text(FORGE_METADATA_URL)
        root = ET.fromstring(xml_text)
        all_versions = [node.text for node in root.iter("version") if node.text]
    except Exception:  # noqa: BLE001
        all_versions = []
    prefix = mc_id + "-"
    builds = []
    for full in all_versions:
        if not full.startswith(prefix):
            continue
        rest = full[len(prefix):]
        if not re.match(r"^\d", rest):
            continue
        builds.append(rest)

    def sort_key(value):
        return tuple(int(part) for part in re.findall(r"\d+", value) if part.isdigit())

    builds.sort(key=sort_key)
    _forge_cache[mc_id] = builds
    return builds


def latest_forge(mc_id):
    builds = forge_versions(mc_id)
    return builds[-1] if builds else None


def _run_installer(java_exe, jar, cwd, log, timeout=1800):
    cmd = [java_exe, "-jar", jar, "--installClient"]
    if log:
        log("$ " + " ".join(cmd))
    proc = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", errors="replace",
                            creationflags=CREATE_NO_WINDOW)
    lines = []
    start = time.time()
    while True:
        line = proc.stdout.readline() if proc.stdout else ""
        if line:
            line = line.rstrip()
            lines.append(line)
            if log and line:
                log(line)
        elif proc.poll() is not None:
            break
        if time.time() - start > timeout:
            proc.kill()
            raise RuntimeError("Установщик Forge не уложился в %d минут" % (timeout // 60))
    proc.wait()
    if proc.returncode != 0:
        tail = "\n".join(lines[-6:])
        raise RuntimeError("Forge installer завершился с кодом %d\n%s" % (proc.returncode, tail))
    return lines


def _ensure_profiles_stub(game):
    path = os.path.join(game.root, "launcher_profiles.json")
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"profiles": {}, "settings": {}, "version": 3}, f)


def install_forge(game, mc_id, forge_version, java_exe, progress=None, log=None):
    forge_version = forge_version or latest_forge(mc_id)
    if not forge_version:
        raise RuntimeError("Forge ещё не выпущен для Minecraft %s" % mc_id)
    full = "%s-%s" % (mc_id, forge_version)
    installer = os.path.join(game.cache_dir, "forge-%s-installer.jar" % full)
    url = "%s/%s/forge-%s-installer.jar" % (FORGE_MAVEN, full, full)
    if progress:
        progress.set_stage("loader", "Скачивание установщика Forge %s" % forge_version)
    errors = net.download_many([{"url": url, "dest": installer, "sha1": None, "size": None}],
                              progress, threads=1)
    if errors:
        raise RuntimeError("Установщик Forge не скачался: " + errors[0])

    game.ensure_dirs()
    _ensure_profiles_stub(game)
    if progress:
        progress.set_stage("loader", "Forge устанавливается (это может занять пару минут)")
    before = set(os.listdir(game.versions_dir)) if os.path.isdir(game.versions_dir) else set()
    _run_installer(java_exe, installer, game.root, log)
    after = set(os.listdir(game.versions_dir)) if os.path.isdir(game.versions_dir) else set()
    created = [name for name in after - before if mc_id in name]
    candidates = created or [name for name in after if mc_id in name and "forge" in name.lower()]
    if not candidates:
        raise RuntimeError("Установщик Forge отработал, но профиль версии не появился")
    candidates.sort(key=len)
    version_id = candidates[-1]
    game._json_cache.pop(version_id, None)
    return version_id


# ---------- OptiFine ----------

_optifine_cache = {"at": 0.0, "versions": [], "catalog": {}}
OPTIFINE_DOWNLOADS = "https://optifine.net/downloads"
OPTIFINE_BASE = "https://optifine.net/"


def _edition_key(edition):
    parts = re.findall(r"(\d+|[A-Z]+)", (edition or "").upper())
    return tuple((1, int(part)) if part.isdigit() else (0, part) for part in parts)


def optifine_catalog(force=False):
    """{версия Minecraft: имя лучшего файла OptiFine} — релизы в приоритете над preview."""
    fresh = time.time() - _optifine_cache["at"] < 6 * 3600
    if not force and fresh and _optifine_cache["catalog"]:
        return dict(_optifine_cache["catalog"])
    try:
        html = net.get_text(OPTIFINE_DOWNLOADS)
    except Exception:  # noqa: BLE001
        return dict(_optifine_cache["catalog"])
    files = []
    for match in re.finditer(r"adloadx\?f=([A-Za-z0-9_.%\-]+\.jar)", html):
        name = match.group(1)
        if name not in files:
            files.append(name)
    best = {}
    for name in files:
        preview = name.startswith("preview_")
        match = re.match(r"(?:preview_)?OptiFine_(\d+(?:\.\d+)+)_(.+)\.jar$", name)
        if not match:
            continue
        mc_id, edition = match.group(1), match.group(2)
        score = (0 if preview else 1, _edition_key(edition))
        if mc_id not in best or score > best[mc_id][0]:
            best[mc_id] = (score, name)
    catalog = {mc_id: value[1] for mc_id, value in best.items()}
    versions = sorted(catalog, key=lambda value: [int(part) for part in value.split(".") if part.isdigit()])
    _optifine_cache.update({"at": time.time(), "versions": versions, "catalog": catalog})
    return dict(catalog)


def optifine_versions(force=False):
    """Версии Minecraft, под которые у OptiFine есть сборка (парсим optifine.net/downloads)."""
    optifine_catalog(force)
    return list(_optifine_cache["versions"])


def optifine_filename(mc_id):
    return optifine_catalog().get(mc_id)


def optifine_support(mc_id, local_jar=None):
    """(поддерживается ли OptiFine для версии, проверено ли по сети, последняя версия)."""
    versions = optifine_versions()
    if not versions:
        return (bool(local_jar), False, None)
    latest = versions[-1] if versions else None
    return (mc_id in versions or bool(local_jar), True, latest)


def find_optifine(game, mc_id):
    patterns = []
    for folder in (os.path.join(game.root, "optifine"), game.root, os.path.join(game.root, "mods")):
        patterns.append(os.path.join(folder, "OptiFine_%s_*.jar" % mc_id))
        patterns.append(os.path.join(folder, "OptiFine_%s_*.jar" % mc_id.replace(".", "_")))
    found = []
    for pattern in patterns:
        found.extend(glob.glob(pattern))
    found = sorted(set(found), key=lambda path: os.path.getmtime(path), reverse=True)
    return found[0] if found else None


def download_optifine(mc_id, dest_dir, progress=None, log=None):
    """Качает OptiFine с optifine.net (adloadx → downloadx) и возвращает путь к jar."""
    name = optifine_filename(mc_id)
    if not name:
        raise RuntimeError("OptiFine не выпущен для Minecraft %s" % mc_id)
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, name)
    if os.path.exists(dest) and os.path.getsize(dest) > 500_000:
        if log:
            log("OptiFine уже скачан: %s" % name)
        return dest
    if progress:
        progress.set_stage("loader", "Скачивание OptiFine %s" % name)
    if log:
        log("Скачиваю OptiFine: %s" % name)
    ad_page = OPTIFINE_BASE + "adloadx?f=" + net.quote(name)
    html = net.get_text(ad_page)
    match = re.search(r"href=['\"](downloadx\?[^'\"]+)['\"]", html)
    if not match:
        raise RuntimeError("OptiFine: optifine.net не отдал ссылку на скачивание, попробуйте позже")
    link = OPTIFINE_BASE + match.group(1).replace("&amp;", "&")
    errors = net.download_many([{
        "url": link, "dest": dest, "sha1": None, "size": None,
        "headers": {"Referer": ad_page, "Accept": "*/*"},
    }], progress, threads=1)
    if errors:
        raise RuntimeError("OptiFine не скачался: " + errors[0])
    with open(dest, "rb") as handle:
        head = handle.read(4)
    if head[:2] != b"PK":
        try:
            os.remove(dest)
        except OSError:
            pass
        raise RuntimeError("OptiFine: вместо jar пришёл другой файл (сайт мог запросить капчу)")
    if log:
        log("OptiFine скачан: %s" % name)
    return dest


def install_optifine_auto(game, mc_id, forge_version, java_exe, progress=None, log=None):
    """Ставит Forge и сам скачивает OptiFine — файлы от пользователя не нужны."""
    jar = find_optifine(game, mc_id)
    if not jar:
        jar = download_optifine(mc_id, os.path.join(game.root, "optifine"), progress, log)
    version_id = install_forge(game, mc_id, forge_version, java_exe, progress, log)
    os.makedirs(game.mods_dir, exist_ok=True)
    target = os.path.join(game.mods_dir, os.path.basename(jar))
    if os.path.abspath(jar) != os.path.abspath(target):
        try:
            shutil.copy2(jar, target)
        except OSError as exc:
            raise RuntimeError("Не удалось положить OptiFine в папку mods: %s" % exc)
    if log:
        log("OptiFine подключён как мод: %s" % os.path.basename(target))
    return version_id, jar


def install_forge_optifine(game, mc_id, forge_version, java_exe, progress=None, log=None):
    return install_optifine_auto(game, mc_id, forge_version, java_exe, progress, log)


def optifine_folder(game):
    path = os.path.join(game.root, "optifine")
    os.makedirs(path, exist_ok=True)
    return path
