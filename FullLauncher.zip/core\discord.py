"""Discord Rich Presence через локальный IPC-канал Discord (без сторонних библиотек).

Кадр: 8 байт заголовка (opcode LE uint32, длина LE uint32) + JSON.
Весь ввод-вывод — в одном потоке в неблокирующем режиме, иначе закрытие
канала на блокирующем read подвешивает лаунчер.
"""

import json
import os
import struct
import threading
import time
import uuid

OP_HANDSHAKE = 0
OP_FRAME = 1
OP_CLOSE = 2
OP_PING = 3
OP_PONG = 4

CLIENT_ID = "1564259805990756382"
PIPE_NAME = r"\\.\pipe\discord-ipc-%d"
RETRY_SECONDS = 8.0
READY_TIMEOUT = 5.0
KEEPALIVE_SECONDS = 20.0


def encode_frame(opcode, payload):
    data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    return struct.pack("<II", int(opcode), len(data)) + data


def decode_header(raw):
    if not raw or len(raw) < 8:
        return None, None
    return struct.unpack("<II", raw[:8])


def find_pipe():
    for index in range(10):
        path = PIPE_NAME % index
        if os.path.exists(path):
            return path
    return None


def build_activity(details, state, large_text, small_text=None, started=None,
                   large_image="logo", small_image="minecraft", buttons=None):
    """Объект активности RPC. Картинки должны быть загружены в приложении Discord."""
    activity = {
        "details": str(details)[:128],
        "state": str(state)[:128],
        "timestamps": {"start": int((started or time.time()) * 1000)},
        "assets": {"large_image": large_image, "large_text": str(large_text)[:128]},
        "instance": True,
    }
    if small_text:
        activity["assets"]["small_image"] = small_image
        activity["assets"]["small_text"] = str(small_text)[:128]
    if buttons:
        activity["buttons"] = buttons[:2]
    return activity


def strip_activity(activity):
    """Копия активности без картинок и кнопок — запасной вариант, если Discord их не принял."""
    if not activity:
        return activity
    clean = {
        "details": activity.get("details", ""),
        "state": activity.get("state", ""),
        "timestamps": activity.get("timestamps") or {"start": int(time.time() * 1000)},
        "instance": True,
    }
    return clean


class DiscordRPC:
    def __init__(self, client_id=CLIENT_ID, on_status=None):
        self.client_id = str(client_id)
        self.on_status = on_status
        self._pipe = None
        self._buffer = b""
        self._lock = threading.Lock()
        self._desired = None
        self._dirty = False
        self._ready = False
        self._assets_ok = True
        self._stop = threading.Event()
        self._thread = None
        self._state = "offline"
        self._detail = "Discord не запущен"
        self._last_error = ""
        self._last_sent_at = 0.0

    # ---------- публичное ----------

    @property
    def alive(self):
        return bool(self._thread and self._thread.is_alive())

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="discord-rpc", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.5)
        self._close_pipe()

    def set_activity(self, activity):
        with self._lock:
            self._desired = activity
            self._dirty = True

    def clear(self):
        with self._lock:
            self._desired = None
            self._dirty = True

    def status(self):
        return {
            "state": self._state,
            "detail": self._detail,
            "connected": self._ready,
            "error": self._last_error,
        }

    # ---------- статус ----------

    def _set_status(self, state, detail=""):
        if (state, detail) == (self._state, self._detail):
            return
        self._state = state
        self._detail = detail
        if self.on_status:
            try:
                self.on_status(state, detail)
            except Exception:  # noqa: BLE001
                pass

    # ---------- канал ----------

    def _open_pipe(self):
        path = find_pipe()
        if not path:
            return False
        try:
            self._pipe = open(path, "r+b", buffering=0)
            os.set_blocking(self._pipe.fileno(), False)
        except (OSError, ValueError):
            self._pipe = None
            return False
        self._buffer = b""
        self._ready = False
        return True

    def _close_pipe(self):
        pipe = self._pipe
        self._pipe = None
        self._buffer = b""
        self._ready = False
        if pipe is not None:
            try:
                pipe.close()
            except Exception:  # noqa: BLE001
                pass

    def _write(self, opcode, payload):
        pipe = self._pipe
        if pipe is None:
            return False
        view = memoryview(encode_frame(opcode, payload))
        deadline = time.time() + 3.0
        while view:
            try:
                written = pipe.write(view)
            except BlockingIOError:
                written = 0
            except (OSError, ValueError):
                return False
            if written:
                view = view[written:]
                continue
            if time.time() > deadline:
                return False
            time.sleep(0.02)
        return True

    # ---------- чтение ----------

    def _read_available(self):
        pipe = self._pipe
        if pipe is None:
            return False
        try:
            chunk = pipe.read(65536)
        except BlockingIOError:
            return True
        except (OSError, ValueError):
            return False
        if chunk is None:
            return True
        if chunk == b"":
            return False
        self._buffer += chunk
        while len(self._buffer) >= 8:
            opcode, length = decode_header(self._buffer[:8])
            if length is None or len(self._buffer) < 8 + length:
                break
            body = self._buffer[8:8 + length]
            self._buffer = self._buffer[8 + length:]
            self._handle_frame(opcode, body)
        return True

    def _handle_frame(self, opcode, body):
        if opcode == OP_PING:
            self._write(OP_PONG, {})
            return
        if opcode == OP_CLOSE:
            self._last_error = "Discord закрыл соединение"
            self._ready = False
            return
        if opcode != OP_FRAME:
            return
        try:
            message = json.loads(body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return
        event = message.get("evt")
        if event == "READY":
            self._ready = True
            user = ((message.get("data") or {}).get("user") or {})
            name = user.get("username") or "Discord"
            self._set_status("connected", "Подключено как %s" % name)
            self._dirty = True
            self._last_sent_at = 0.0
        elif event == "ERROR":
            data = message.get("data") or {}
            code = data.get("code")
            text = data.get("message") or ""
            self._last_error = "%s %s" % (code or "", text)
            self._set_status("error", "Discord: %s" % (text or code or "ошибка"))
            if self._assets_ok:
                # Скорее всего не загружены ассеты — повторяем без картинок
                self._assets_ok = False
                with self._lock:
                    if self._desired:
                        self._desired = strip_activity(self._desired)
                        self._dirty = True

    # ---------- отправка активности ----------

    def _push(self, force=False):
        if not self._ready or self._pipe is None:
            return
        with self._lock:
            if not self._dirty and not force:
                return
            activity = self._desired
            self._dirty = False
        self._write(OP_FRAME, {
            "cmd": "SET_ACTIVITY",
            "args": {"pid": os.getpid(), "activity": activity},
            "nonce": str(uuid.uuid4()),
        })
        self._last_sent_at = time.time()

    # ---------- цикл ----------

    def _connect(self):
        if not self._open_pipe():
            return False
        self._set_status("connecting", "Подключаюсь к Discord…")
        if not self._write(OP_HANDSHAKE, {"v": 1, "client_id": self.client_id}):
            self._close_pipe()
            return False
        deadline = time.time() + READY_TIMEOUT
        while time.time() < deadline:
            if self._stop.is_set():
                return False
            if not self._read_available():
                break
            if self._ready:
                return True
            time.sleep(0.03)
        self._last_error = "Discord не ответил на handshake"
        self._close_pipe()
        return False

    def _loop(self):
        while not self._stop.is_set():
            if self._pipe is None:
                if not self._connect():
                    self._set_status("offline", "Discord не запущен")
                    self._stop.wait(RETRY_SECONDS)
                    continue
            if not self._read_available():
                self._last_error = "соединение потеряно"
                self._close_pipe()
                self._set_status("offline", "Нет соединения с Discord")
                continue
            self._push()
            if (self._ready and self._desired is not None
                    and time.time() - self._last_sent_at > KEEPALIVE_SECONDS):
                self._push(force=True)
            self._stop.wait(0.1)
        self._close_pipe()
        self._ready = False
        self._set_status("offline", "Rich Presence остановлен")
