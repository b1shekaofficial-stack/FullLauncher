﻿"""Full Launcher — точка входа: окно, мост JS <-> Python, установка и запуск игры."""

import ctypes
import json
import os
import re
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from functools import partial

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import webview  # noqa: E402

from core import config as cfg_mod  # noqa: E402
from core import java as java_mod  # noqa: E402
from core import loaders as loaders_mod  # noqa: E402
from core import mc as mc_mod  # noqa: E402
from core import mods as mods_mod  # noqa: E402
from core import net  # noqa: E402

APP_TITLE = "Full Launcher"
APP_VERSION = "1.0.0"
UI_DIR = os.path.join(BASE_DIR, "ui")
ASSETS_DIR = os.path.join(BASE_DIR, "assets")
ICON_PATH = os.path.join(ASSETS_DIR, "icon.ico")
GAME_ROOT = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "FullLauncher")
LOG_DIR = os.path.join(GAME_ROOT, "logs")
CREATE_NEW_PROCESS_GROUP = 0x00000200
DETACHED_PROCESS = 0x00000008

NICK_RE = re.compile(cfg_mod.VALID_NICK)

from core import discord as discord_mod  # noqa: E402
from core import nbt as nbt_mod  # noqa: E402

# Список рекомендуемых серверов. Пока пусто — в интерфейсе показывается заглушка.
# Позже сюда (или в %APPDATA%\FullLauncher\servers.json) добавятся сервера,
# и у каждого появится кнопка «Добавить» — она пишет сервер в servers.dat игры.
SERVERS = [
    {
        "name": "Mineblaze",
        "ip": "mc.mineblaze.net",
        "versions": "1.8 – 26.3",
        "tag": "Выживание · мини-игры",
        "color": "#ff8a3d",
        "note": ("Выживание, гриферский режим и мини-игры: BedWars, SkyWars, KitPvP и дуэли. "
                 "Онлайн в среднем ~3 000 игроков."),
        "avatar": "servers/mineblaze.png",
        "hit": True,
    },
]
SERVERS_FILE = "servers.json"

NEWS = [
    {
        "tag": "ОТКРЫТИЕ",
        "date": "26.10.2026",
        "title": "Full Launcher открыт для пользования",
        "text": ("Лаунчер полностью открыт: ставьте любую версию от 1.7.10 до 26.3, "
                 "выбирайте Forge, Fabric, OptiFine — и запускайте в один клик. "
                 "Никаких ключей и подписок, всё бесплатно."),
        "cover": "news-cover.jpg",
        "featured": True,
    },
    {
        "tag": "ОБНОВЛЕНИЕ",
        "date": "26.10.2026",
        "title": "Minecraft 26.3 уже в списке",
        "text": ("Список версий тянется напрямую из манифеста Mojang, поэтому новые релизы "
                 "появляются в лаунчере в день выхода."),
    },
    {
        "tag": "МОДЫ",
        "date": "26.10.2026",
        "title": "Моды в один клик",
        "text": ("Каталог Modrinth внутри лаунчера: ищите моды под свою версию и модлоадер "
                 "и ставьте их без браузера."),
    },
    {
        "tag": "СЕРВЕРЫ",
        "date": "26.10.2026",
        "title": "Свой сервер в списке",
        "text": "Хотите видеть свой сервер в рекомендациях? Напишите @Azbu4ka в Telegram.",
    },
    {
        "tag": "JAVA",
        "date": "26.10.2026",
        "title": "Java ставится сама",
        "text": ("Лаунчер сам подбирает и скачивает официальный рантайм Mojang под версию "
                 "игры — вручную ставить Java больше не нужно."),
    },
]


class UiServer:
    """Локальный мини-сервер для отдачи интерфейса в WebView."""

    def __init__(self, directory):
        handler = partial(SimpleHTTPRequestHandler, directory=directory)
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()

    @property
    def url(self):
        return "http://127.0.0.1:%d/ui/index.html" % self.port

    def stop(self):
        try:
            self.httpd.shutdown()
        except Exception:  # noqa: BLE001
            pass


class Api:
    def __init__(self, game, cfg):
        self._game = game
        self._cfg = cfg
        self._window = None
        self._events = []
        self._lock = threading.Lock()
        self._progress = net.Progress(sink=self._on_progress)
        self._job_thread = None
        self._stop = threading.Event()
        self._busy = False
        self._game_proc = None
        self._manifest_ready = False
        self._releases = []
        self._launcher_started = time.time()
        self._game_started = None
        self._rpc_state = {"state": "offline", "detail": "Discord не запущен"}
        self._rpc = discord_mod.DiscordRPC(on_status=self._on_rpc_status)
        _log_line("Discord RPC: при старте discord_rpc=%s" % bool(self._cfg.get("discord_rpc", True)))
        if self._cfg.get("discord_rpc", True):
            self._rpc.start()
        self._rpc_watch = threading.Thread(target=self._rpc_watchdog, name="rpc-watchdog", daemon=True)
        self._rpc_watch.start()

    # ---------- Discord Rich Presence ----------

    def _on_rpc_status(self, state, detail):
        self._rpc_state = {"state": state, "detail": detail}
        _log_line("Discord RPC: %s — %s" % (state, detail or ""))
        self._emit("rpc", self._rpc_state)

    def _rpc_watchdog(self):
        """Раз в 15 секунд проверяет, что поток RPC жив, и поднимает его заново."""
        while True:
            time.sleep(15)
            try:
                if not self._cfg.get("discord_rpc", True):
                    continue
                if not self._rpc.alive:
                    _log_line("Discord RPC: поток не жив — перезапускаю")
                    self._rpc = discord_mod.DiscordRPC(on_status=self._on_rpc_status)
                    self._rpc.start()
                    self._update_presence(playing=bool(self._game_started))
            except Exception as exc:  # noqa: BLE001
                _log_line("Discord RPC watchdog: %s" % exc)

    def _client_label(self):
        version = self._cfg.get("version") or "версия не выбрана"
        loader = self._cfg.get("loader") or "vanilla"
        if loader == "vanilla":
            return version
        names = {"forge": "Forge", "fabric": "Fabric",
                 "forgeoptifine": "Forge + OptiFine", "optifine": "OptiFine"}
        return "%s · %s" % (version, names.get(loader, loader))

    def _update_presence(self, playing=False):
        if not self._cfg.get("discord_rpc", True):
            self._rpc.clear()
            return
        buttons = [{"label": "Telegram", "url": "https://t.me/FullLauncher"}]
        client = self._client_label()
        if playing:
            activity = discord_mod.build_activity(
                "Играет в Minecraft", client, "Full Launcher", client,
                self._game_started or time.time(), buttons=buttons)
        else:
            activity = discord_mod.build_activity(
                "В лаунчере", "Клиент: %s" % client, "Full Launcher", None,
                self._launcher_started, buttons=buttons)
        self._rpc.set_activity(activity)

    def rpc_status(self):
        status = dict(self._rpc_state)
        status["enabled"] = bool(self._cfg.get("discord_rpc", True))
        status["clientId"] = discord_mod.CLIENT_ID
        return status

    def set_rpc_enabled(self, enabled):
        enabled = bool(enabled)
        self._cfg.update({"discord_rpc": enabled})
        if enabled:
            self._rpc.start()
            if not (self._rpc_watch and self._rpc_watch.is_alive()):
                self._rpc_watch = threading.Thread(target=self._rpc_watchdog, name="rpc-watchdog",
                                                   daemon=True)
                self._rpc_watch.start()
            self._update_presence(playing=bool(self._game_started))
        else:
            self._rpc.clear()
            self._rpc.stop()
            self._rpc_state = {"state": "disabled", "detail": "Rich Presence выключен"}
        return self.rpc_status()

    # ---------- события ----------

    def _emit(self, kind, payload=None):
        with self._lock:
            self._events.append({"type": kind, "data": payload})
            if len(self._events) > 400:
                del self._events[:200]

    def _on_progress(self, snapshot):
        self._emit("progress", snapshot)

    def _log(self, line):
        text = str(line).strip()
        if text:
            self._emit("log", text)

    def poll(self):
        with self._lock:
            events = self._events
            self._events = []
        return events

    def _toast(self, text, kind="info"):
        self._emit("toast", {"text": text, "kind": kind})

    # ---------- состояние ----------

    def _nickname_ok(self, nickname):
        return bool(NICK_RE.match(nickname or ""))

    def _server_catalog(self):
        entries = list(SERVERS)
        path = os.path.join(self._game.root, SERVERS_FILE)
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    extra = json.load(f)
                if isinstance(extra, list):
                    entries.extend(item for item in extra if isinstance(item, dict) and item.get("ip"))
            except (OSError, ValueError):
                pass
        return entries

    def _servers(self):
        saved = {}
        for item in nbt_mod.load(nbt_mod.servers_path(self._game.root)):
            address = str(item.get("ip") or "").strip().lower()
            if address:
                saved[address] = item.get("name") or address
        result = []
        for item in self._server_catalog():
            entry = dict(item)
            address = str(entry.get("ip") or "").strip()
            entry["installed"] = address.lower() in saved
            entry.setdefault("name", address)
            entry.setdefault("tag", "Сервер")
            entry.setdefault("color", "#8b5cf6")
            entry.setdefault("note", "")
            entry.setdefault("versions", "")
            entry.setdefault("avatar", "")
            entry.setdefault("hit", False)
            result.append(entry)
        return result

    def add_server(self, name, ip):
        """Добавляет сервер в servers.dat выбранного клиента (папка игры)."""
        try:
            outcome = nbt_mod.add_server(nbt_mod.servers_path(self._game.root), name, ip,
                                        compressed=self._servers_compressed())
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": str(exc)}
        pinned = [str(item) for item in (self._cfg.get("servers_pinned") or [])]
        if ip and str(ip).lower() not in [item.lower() for item in pinned]:
            pinned.append(str(ip))
            self._cfg.update({"servers_pinned": pinned})
        running = bool(self._game_proc and self._game_proc.poll() is None)
        if running:
            self._toast("Сервер записан. Перезапустите Minecraft — список читается при запуске", "warn")
        elif outcome.get("added"):
            self._toast("Сервер %s добавлен в Minecraft" % (name or ip), "ok")
        elif outcome.get("renamed"):
            self._toast("Сервер уже был — имя обновлено", "warn")
        else:
            self._toast("Этот сервер уже есть в списке Minecraft", "warn")
        return {
            "ok": True,
            "added": outcome.get("added"),
            "already": outcome.get("already"),
            "total": outcome.get("total"),
            "gameRunning": running,
            "path": nbt_mod.servers_path(self._game.root),
            "servers": self._servers(),
        }

    def _release_time(self, version_id):
        try:
            meta = self._game.version_index().get(version_id) or {}
            return (meta.get("releaseTime") or "")[:10]
        except Exception:  # noqa: BLE001
            return ""

    def _servers_compressed(self):
        """Формат servers.dat: старые версии — gzip, 26.x — простой NBT."""
        existing = nbt_mod.is_compressed(nbt_mod.servers_path(self._game.root))
        if existing is not None:
            return existing
        released = self._release_time(self._cfg.get("version") or "")
        return bool(released and released < "2024-04-01")

    def _sync_pinned_servers(self):
        """Возвращает добавленные лаунчером сервера в servers.dat (игра его перезаписывает)."""
        pinned = [str(item) for item in (self._cfg.get("servers_pinned") or [])]
        if not pinned:
            return 0
        catalog = {str(item.get("ip", "")).lower(): item for item in self._server_catalog()}
        compressed = self._servers_compressed()
        path = nbt_mod.servers_path(self._game.root)
        restored = 0
        for ip in pinned:
            entry = catalog.get(ip.lower()) or {"name": ip, "ip": ip}
            try:
                result = nbt_mod.add_server(path, entry.get("name") or ip, ip, compressed=compressed)
            except Exception as exc:  # noqa: BLE001
                _log_line("сервера: не удалось записать %s (%s)" % (ip, exc))
                continue
            if result.get("added") or result.get("renamed"):
                restored += 1
        if restored:
            _log_line("сервера: восстановлено в servers.dat — %d" % restored)
        return restored

    def remove_server(self, ip):
        path = nbt_mod.servers_path(self._game.root)
        try:
            servers = [s for s in nbt_mod.load(path)
                       if str(s.get("ip", "")).strip().lower() != str(ip or "").strip().lower()]
            nbt_mod.save(path, servers)
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": str(exc)}
        pinned = [item for item in (self._cfg.get("servers_pinned") or [])
                  if str(item).lower() != str(ip).lower()]
        self._cfg.update({"servers_pinned": pinned})
        return {"ok": True, "servers": self._servers()}

    def bootstrap(self):
        game = self._game
        game.ensure_dirs()
        error = None
        try:
            releases = game.releases()
            latest = game.manifest().get("latest", {}).get("release")
            self._releases = releases
            self._manifest_ready = True
        except Exception as exc:  # noqa: BLE001
            error = str(exc)
            latest = None
        if not self._cfg.get("version") and self._releases:
            preferred = None
            for vid in ("1.21.8", "1.21.4", "1.20.1", "1.12.2"):
                if any(v["id"] == vid for v in self._releases):
                    preferred = vid
                    break
            self._cfg.data["version"] = preferred or self._releases[0]["id"]
            self._cfg.save()
        self._update_presence(playing=bool(self._game_started))
        return {
            "ok": error is None,
            "error": error,
            "appVersion": APP_VERSION,
            "latest": latest,
            "config": self._cfg.data,
            "nicknameValid": self._nickname_ok(self._cfg.get("nickname")),
            "gameRoot": game.root,
            "modsDir": game.mods_dir,
            "shaderDir": game.shaderpacks_dir,
            "optifineDir": os.path.join(game.root, "optifine"),
            "servers": self._servers(),
            "news": NEWS,
            "installed": game.installed_versions(),
            "java": java_mod.detect(game),
            "javaOk": len(java_mod.detect(game)) > 0,
            "totalReleases": len(self._releases),
        }

    def versions(self):
        if not self._releases:
            try:
                self._releases = self._game.releases()
            except Exception as exc:  # noqa: BLE001
                return {"ok": False, "error": str(exc), "releases": []}
        recommended = {"26.3", "1.21.8", "1.21.4", "1.20.1", "1.16.5", "1.12.2", "1.8.9", "1.7.10"}
        payload = []
        for item in self._releases:
            payload.append({
                "id": item["id"],
                "type": item.get("type"),
                "released": (item.get("releaseTime") or "")[:10],
                "recommended": item["id"] in recommended,
            })
        return {"ok": True, "releases": payload, "latest": self._game.manifest().get("latest", {}).get("release")}

    def loaders_for(self, version_id):
        fabric = loaders_mod.fabric_versions(version_id)
        forge = loaders_mod.forge_versions(version_id)
        optifine_jar = loaders_mod.find_optifine(self._game, version_id)
        optifine_ok, checked, optifine_latest = loaders_mod.optifine_support(version_id, optifine_jar)
        reason = None
        if not forge:
            reason = "Forge нет под %s" % version_id
        elif not optifine_ok:
            reason = "OptiFine нет под %s" % version_id
            if optifine_latest:
                reason += " (последняя — %s)" % optifine_latest
        return {
            "ok": True,
            "fabric": [v["version"] for v in fabric][:15],
            "forge": list(reversed(forge))[:15],
            "optifine": bool(optifine_jar),
            "optifineFile": os.path.basename(optifine_jar) if optifine_jar else None,
            "optifineSupported": optifine_ok,
            "optifineChecked": checked,
            "optifineLatest": optifine_latest,
            "forgeOptifineSupported": bool(forge) and optifine_ok,
            "forgeOptifineReason": reason,
        }

    def get_config(self):
        """Быстрая выдача сохранённого конфига — без сети, сразу после старта окна."""
        return {
            "ok": True,
            "config": dict(self._cfg.data),
            "nicknameValid": self._nickname_ok(self._cfg.get("nickname")),
            "gameRoot": self._game.root,
        }

    def set_config(self, patch_json):
        try:
            patch = json.loads(patch_json) if isinstance(patch_json, str) else dict(patch_json)
        except (TypeError, ValueError):
            return {"ok": False, "error": "bad payload"}
        data = self._cfg.update(patch)
        if "discord_rpc" in patch:
            self.set_rpc_enabled(bool(patch["discord_rpc"]))
        else:
            self._update_presence(playing=bool(self._game_started))
        return {"ok": True, "config": data,
                "nicknameValid": self._nickname_ok(data.get("nickname"))}

    # ---------- игра ----------

    def play(self, request_json):
        try:
            req = json.loads(request_json) if isinstance(request_json, str) else dict(request_json)
        except (TypeError, ValueError):
            return {"ok": False, "error": "bad payload"}
        if self._busy:
            return {"ok": False, "error": "Установка уже идёт"}
        nickname = (req.get("nickname") or "").strip()
        if not self._nickname_ok(nickname):
            return {"ok": False, "error": "Введите ник: 3–16 символов, буквы, цифры и _"}
        version_id = req.get("version")
        if not version_id:
            return {"ok": False, "error": "Сначала выберите клиент"}
        loader = req.get("loader") or "vanilla"
        loader_version = req.get("loaderVersion") or ""
        ram = int(req.get("ram") or self._cfg.get("ram") or 4096)
        width = int(self._cfg.get("width") or 925)
        height = int(self._cfg.get("height") or 530)

        self._cfg.update({"nickname": nickname, "version": version_id,
                         "loader": loader, "loader_version": loader_version, "ram": ram})
        self._stop.clear()
        self._busy = True
        self._emit("job", {"state": "running", "version": version_id, "loader": loader})
        self._progress.reset()
        self._progress.set_stage("start", "Подготовка")
        self._job_thread = threading.Thread(
            target=self._job_play,
            args=(version_id, loader, loader_version, nickname, ram, width, height),
            daemon=True,
        )
        self._job_thread.start()
        return {"ok": True}

    def cancel(self):
        if not self._busy:
            return {"ok": False}
        self._stop.set()
        self._toast("Останавливаю после текущего шага…", "warn")
        return {"ok": True}

    def _ensure_launch_java(self, merged):
        return java_mod.resolve(self._game, merged, self._progress)

    def _job_play(self, version_id, loader, loader_version, nickname, ram, width, height):
        game = self._game
        try:
            target = version_id
            if loader in ("forgeoptifine", "optifine"):
                local_jar = loaders_mod.find_optifine(game, version_id)
                supported, checked, latest = loaders_mod.optifine_support(version_id, local_jar)
                if checked and not supported:
                    raise RuntimeError(
                        "OptiFine не выпущен для Minecraft %s%s. Выберите другую версию "
                        "или клиент Forge без OptiFine." % (
                            version_id, (" (последняя версия OptiFine — %s)" % latest) if latest else ""))
            if loader == "fabric":
                target = loaders_mod.install_fabric(game, version_id, loader_version, self._progress)
            elif loader in ("forge", "forgeoptifine", "optifine"):
                vanilla = game.merged(version_id)
                java_exe, _major, _fresh = self._ensure_launch_java(vanilla)
                if self._stop.is_set():
                    raise RuntimeError("cancelled")
                if loader == "forge":
                    target = loaders_mod.install_forge(game, version_id, loader_version,
                                                       java_exe, self._progress, self._log)
                else:
                    # OptiFine скачивается и ставится автоматически: Forge + jar в mods
                    target, optifine_jar = loaders_mod.install_optifine_auto(
                        game, version_id, loader_version, java_exe, self._progress, self._log)
                    self._log("OptiFine подключён: %s" % os.path.basename(optifine_jar))
            if self._stop.is_set():
                raise RuntimeError("cancelled")

            merged = game.merged(target)
            self._progress.set_stage("files", "Проверка файлов %s" % target)
            installed = game.install(target, self._progress)
            if self._stop.is_set():
                raise RuntimeError("cancelled")

            java_exe, java_version, downloaded = java_mod.resolve(game, merged, self._progress)
            self._log("Java %d: %s%s" % (java_version, java_exe,
                                        " (скачан)" if downloaded else ""))
            asset_index = (merged.get("assetIndex") or {}).get("id")
            classpath = game.classpath(merged, installed["jar"])
            if not classpath:
                raise RuntimeError("Не собрался classpath — библиотеки не установлены")
            cmd = game.build_command(merged, {
                "java": java_exe,
                "nickname": nickname,
                "ram": ram,
                "width": width,
                "height": height,
                "game_dir": game.root,
                "natives_dir": installed["natives"],
                "classpath": classpath,
                "asset_index": asset_index,
                "log_conf": installed["log"],
                "version_name": target,
                "launcher_version": APP_VERSION,
            })
            self._progress.set_stage("done", "Запуск Minecraft")
            self._emit("progress", dict(self._progress.snapshot(), percent=100.0))
            self._log("Команда запуска: " + " ".join(cmd[:6]) + " …")
            with open(os.path.join(game.cache_dir, "last-launch.txt"), "w", encoding="utf-8") as f:
                f.write(" ".join(cmd))
            flags = CREATE_NEW_PROCESS_GROUP | DETACHED_PROCESS
            self._sync_pinned_servers()
            logs_dir = os.path.join(game.root, "logs")
            os.makedirs(logs_dir, exist_ok=True)
            game_log = os.path.join(logs_dir, "game-latest.log")
            try:
                with open(game_log, "wb"):
                    pass
                out_handle = open(game_log, "ab")
            except OSError:
                out_handle = subprocess.DEVNULL
            with open(os.path.join(logs_dir, "game-latest.cmd.txt"), "w", encoding="utf-8") as f:
                f.write(" ".join(cmd))
            self._game_proc = subprocess.Popen(cmd, cwd=game.root, close_fds=True,
                                               stdout=out_handle, stderr=subprocess.STDOUT,
                                               creationflags=flags)
            if out_handle is not subprocess.DEVNULL:
                out_handle.close()
            self._cfg.update({"lastVersion": target})
            self._game_started = time.time()
            self._update_presence(playing=True)
            self._emit("job", {"state": "launched", "version": target, "pid": self._game_proc.pid})
            threading.Thread(target=self._watch_game, args=(self._game_proc,), daemon=True).start()
        except Exception as exc:  # noqa: BLE001
            message = str(exc)
            self._game_started = None
            self._update_presence(playing=False)
            if message == "cancelled":
                self._emit("job", {"state": "cancelled"})
                self._toast("Установка отменена", "warn")
            else:
                self._emit("job", {"state": "error", "message": message})
        finally:
            self._busy = False

    def _tail_game_log(self, limit=1600):
        path = os.path.join(self._game.root, "logs", "game-latest.log")
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                text = f.read()
        except OSError:
            return ""
        text = text.strip()
        return text[-limit:] if text else ""

    def _watch_game(self, proc):
        started = self._game_started or time.time()
        try:
            code = proc.wait()
        except Exception:  # noqa: BLE001
            code = None
        elapsed = time.time() - started
        time.sleep(1.2)
        self._game_started = None
        self._update_presence(playing=False)
        self._sync_pinned_servers()
        if code not in (0, None) and elapsed < 90:
            tail = self._tail_game_log()
            self._emit("job", {
                "state": "error",
                "message": "Minecraft закрылся с кодом %s через %.0f с. Лог игры: logs/game-latest.log\n%s"
                           % (code, elapsed, tail[-900:] if tail else "лог пуст"),
            })
            self._emit("toast", {"text": "Minecraft не запустился — смотри logs/game-latest.log", "kind": "err"})
        else:
            self._log("Minecraft закрыт")

    # ---------- моды ----------

    def mods_search(self, payload_json):
        try:
            req = json.loads(payload_json) if isinstance(payload_json, str) else dict(payload_json)
        except (TypeError, ValueError):
            return {"available": False, "error": "bad payload", "hits": [], "kind": "mod"}
        kind = req.get("kind") or mods_mod.KIND_MOD
        loader = req.get("loader") or self._cfg.get("loader") or "vanilla"
        version_id = req.get("version") or self._cfg.get("version")
        query = (req.get("query") or "").strip()
        if not version_id or not mods_mod.supports_kind(kind, loader):
            return {"available": False, "error": "unavailable", "hits": [], "kind": kind}
        result = mods_mod.search(loader, version_id, query,
                                 page=int(req.get("page") or 1),
                                 per_page=int(req.get("perPage") or mods_mod.PER_PAGE),
                                 kind=kind)
        result["installed"] = sorted(
            {item["file"] for item in mods_mod.installed(self._kind_dir(kind), kind)})
        result["loader"] = loader
        result["version"] = version_id
        result["kind"] = kind
        return result

    def _kind_dir(self, kind):
        if kind == mods_mod.KIND_SHADER:
            return self._game.shaderpacks_dir
        return self._game.mods_dir

    def mods_installed(self, kind=None):
        kind = kind or mods_mod.KIND_MOD
        return mods_mod.installed(self._kind_dir(kind), kind)

    def mod_install(self, payload_json):
        try:
            req = json.loads(payload_json) if isinstance(payload_json, str) else dict(payload_json)
        except (TypeError, ValueError):
            return {"ok": False, "error": "bad payload"}
        project_id = req.get("id")
        kind = req.get("kind") or mods_mod.KIND_MOD
        loader = req.get("loader") or self._cfg.get("loader")
        version_id = req.get("version") or self._cfg.get("version")
        if not project_id or not version_id:
            return {"ok": False, "error": "Не выбран клиент"}
        try:
            self._progress.reset()
            result = mods_mod.install(project_id, loader, version_id,
                                      self._kind_dir(kind), self._progress, kind=kind)
            label = "Шейдер установлен" if kind == mods_mod.KIND_SHADER else "Мод установлен"
            self._toast("%s: %s" % (label, result["file"]), "ok")
            return {"ok": True, "result": result}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": str(exc)}

    def mod_remove(self, filename, kind=None):
        kind = kind or mods_mod.KIND_MOD
        try:
            removed = mods_mod.remove(self._kind_dir(kind), filename)
            return {"ok": removed}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": str(exc)}

    # ---------- прочее ----------

    def open_folder(self, which):
        mapping = {
            "root": self._game.root,
            "mods": self._game.mods_dir,
            "shaderpacks": self._game.shaderpacks_dir,
            "optifine": os.path.join(self._game.root, "optifine"),
            "versions": self._game.versions_dir,
            "logs": os.path.join(self._game.root, "logs"),
            "cache": self._game.cache_dir,
        }
        path = mapping.get(which) or self._game.root
        os.makedirs(path, exist_ok=True)
        try:
            os.startfile(path)  # noqa: S606
        except Exception:  # noqa: BLE001
            subprocess.Popen(["explorer", path])
        return {"ok": True, "path": path}

    def open_url(self, url):
        if isinstance(url, str) and url.startswith(("http://", "https://", "tg://")):
            webbrowser.open(url)
            return {"ok": True}
        return {"ok": False}

    def java_list(self):
        return {"ok": True, "javas": java_mod.detect(self._game)}

    def clear_cache(self):
        path = os.path.join(self._game.cache_dir, "version_manifest_v2.json")
        if os.path.exists(path):
            os.remove(path)
        return {"ok": True}

    def minimize(self):
        if self._window:
            self._window.minimize()
        return {"ok": True}

    def toggle_maximize(self):
        if self._window:
            try:
                self._window.toggle_fullscreen()
            except Exception:  # noqa: BLE001
                pass
        return {"ok": True}

    def close(self):
        # Конфиг сохраняется при каждом изменении; здесь НЕ сохраняем, иначе
        # устаревший экземпляр затирает свежие настройки при выходе.
        try:
            self._rpc.clear()
        except Exception:  # noqa: BLE001
            pass
        try:
            self._rpc.stop()
        except Exception:  # noqa: BLE001
            pass
        if self._window:
            self._window.destroy()
        return {"ok": True}


def _log_line(text):
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(os.path.join(LOG_DIR, "launcher.log"), "a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), text))
    except OSError:
        pass


def _setup_runtime():
    """pythonw.exe не имеет консоли: уводим потоки в лог и ловим падения."""
    os.makedirs(LOG_DIR, exist_ok=True)
    log_path = os.path.join(LOG_DIR, "launcher.log")
    if sys.stdout is None or sys.stderr is None:
        stream = open(log_path, "a", encoding="utf-8", buffering=1)
        if sys.stdout is None:
            sys.stdout = stream
        if sys.stderr is None:
            sys.stderr = stream

    def hook(exc_type, exc, tb):
        text = "".join(traceback.format_exception(exc_type, exc, tb))
        _log_line("FATAL\n" + text)
        try:
            ctypes.windll.user32.MessageBoxW(None, text[-1500:],
                                             "Full Launcher — ошибка запуска", 0x10)
        except Exception:  # noqa: BLE001
            pass

    sys.excepthook = hook
    threading.excepthook = lambda args: hook(args.exc_type, args.exc_value, args.exc_traceback)
    return log_path


_MUTEX = None


def _single_instance():
    """True, если лаунчер уже запущен — тогда просто поднимаем его окно."""
    global _MUTEX
    try:
        kernel32 = ctypes.windll.kernel32
        _MUTEX = kernel32.CreateMutexW(None, False, "Local\\FullLauncher_SingleInstance")
        return kernel32.GetLastError() == 183
    except Exception:  # noqa: BLE001
        return False


def _activate_window(title):
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.FindWindowW(None, title)
        if not hwnd:
            return False
        user32.ShowWindow(hwnd, 5)
        flags = 0x0001 | 0x0002 | 0x0040
        user32.SetWindowPos(hwnd, ctypes.c_void_p(-1), 0, 0, 0, 0, flags)
        user32.SetWindowPos(hwnd, ctypes.c_void_p(-2), 0, 0, 0, 0, flags)
        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
        user32.FlashWindow(hwnd, True)
        return True
    except Exception:  # noqa: BLE001
        return False


def set_window_icon(title):
    if os.name != "nt" or not os.path.exists(ICON_PATH):
        return
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.FindWindowW(None, title)
        if not hwnd:
            return
        IMAGE_ICON, LR_LOADFROMFILE, LR_DEFAULTSIZE = 1, 0x0010, 0x0040
        WM_SETICON, ICON_SMALL, ICON_BIG = 0x0080, 0, 1
        for size in (ICON_SMALL, ICON_BIG):
            handle = user32.LoadImageW(None, ICON_PATH, IMAGE_ICON, 0, 0,
                                       LR_LOADFROMFILE | LR_DEFAULTSIZE)
            if handle:
                user32.SendMessageW(hwnd, WM_SETICON, size, handle)
    except Exception:  # noqa: BLE001
        pass
    _activate_window(title)


def _centered_position(width, height):
    try:
        user32 = ctypes.windll.user32
        screen_w = user32.GetSystemMetrics(0)
        screen_h = user32.GetSystemMetrics(1)
        if screen_w > 0 and screen_h > 0:
            return max(0, (screen_w - width) // 2), max(0, (screen_h - height) // 2)
    except Exception:  # noqa: BLE001
        pass
    return None, None


def main():
    _setup_runtime()
    if _single_instance():
        if _activate_window(APP_TITLE):
            _log_line("второй экземпляр: поднял уже открытое окно")
        else:
            _log_line("второй экземпляр: окно не найдено")
        return
    _log_line("=== старт Full Launcher %s ===" % APP_VERSION)
    if not (os.path.exists(os.path.join(GAME_ROOT, "webview"))
            or os.environ.get("WEBVIEW2_USER_DATA_FOLDER")):
        _log_line("WebView2 профиль создаётся заново")
    cfg = cfg_mod.Config(os.path.join(GAME_ROOT, "config.json"))
    filled = cfg.materialize()
    if filled:
        _log_line("конфиг: дописаны значения по умолчанию — %s" % ", ".join(filled))
    game = mc_mod.Game(GAME_ROOT)
    api = Api(game, cfg)
    server = UiServer(BASE_DIR)
    _log_line("UI-сервер: %s" % server.url)
    win_w, win_h = 1280, 812
    pos_x, pos_y = _centered_position(win_w, win_h)
    window = webview.create_window(
        APP_TITLE,
        server.url,
        js_api=api,
        width=win_w,
        height=win_h,
        x=pos_x,
        y=pos_y,
        min_size=(1080, 700),
        resizable=True,
        frameless=True,
        easy_drag=False,
        background_color="#07070C",
        text_select=False,
        zoomable=False,
        confirm_close=False,
    )
    api._window = window

    def on_start():
        time.sleep(0.9)
        set_window_icon(APP_TITLE)
        time.sleep(1.6)
        _activate_window(APP_TITLE)
        _log_line("окно показано, позиция %s,%s" % (pos_x, pos_y))

    threading.Thread(target=on_start, daemon=True).start()
    try:
        webview.start(debug=("--debug" in sys.argv),
                      icon=ICON_PATH if os.path.exists(ICON_PATH) else None,
                      private_mode=False, storage_path=os.path.join(GAME_ROOT, "webview"))
    except Exception:
        _log_line("webview.start упал\n" + traceback.format_exc())
        raise
    finally:
        server.stop()
    _log_line("=== выход ===")


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        from tools.selftest import run as run_selftest
        run_selftest(sys.argv[1:])
    else:
        main()
