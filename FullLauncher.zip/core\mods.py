"""Каталог модов и шейдеров через открытый API Modrinth: поиск, скачивание, установленные."""

import json
import os
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

from . import net

MODRINTH = "https://api.modrinth.com/v2"
MOD_LOADERS = {"forge", "fabric", "forgeoptifine", "neoforge", "quilt"}
MOD_LOADER_NAMES = {"forge": "Forge", "fabric": "Fabric", "neoforge": "NeoForge", "quilt": "Quilt"}
SHADER_LOADERS = {"optifine", "forgeoptifine"}
PER_PAGE = 21
MAX_ITEMS = 100
MAX_MODS = MAX_ITEMS

KIND_MOD = "mod"
KIND_SHADER = "shader"

_avail_cache = {}
AVAIL_TTL = 900


def _json_param(value):
    return json.dumps(value, separators=(",", ":"))


def supports_mods(loader):
    return loader in MOD_LOADERS


def supports_kind(kind, loader):
    if kind == KIND_SHADER:
        return loader in SHADER_LOADERS
    return supports_mods(loader)


def modrinth_loader(loader):
    if loader == "forgeoptifine":
        return "forge"
    return loader if loader in ("forge", "fabric", "neoforge", "quilt") else "forge"


def _version_key(value):
    parts = [int(part) for part in urllib.parse.unquote("" if value is None else str(value)).replace("-", ".").split(".")
             if part.isdigit()]
    return tuple(parts) if parts else (0,)


def _facets(kind, loader):
    if kind == KIND_SHADER:
        return [["project_type:shader"], ["categories:optifine"]], "optifine"
    target = modrinth_loader(loader)
    return [["project_type:mod"], ["categories:%s" % target]], target


def availability(project_id, mc_id, kind=KIND_MOD):
    """Загрузчики, у которых реально есть файл под эту версию игры.

    Возвращает set() или None, если проверить не удалось (тогда верим поиску).
    """
    key = (kind, project_id, mc_id)
    now = time.time()
    cached = _avail_cache.get(key)
    if cached and now - cached[0] < AVAIL_TTL:
        return cached[1]
    params = {"game_versions": _json_param([mc_id])}
    if kind == KIND_SHADER:
        params["loaders"] = _json_param(["optifine"])
    url = "%s/project/%s/version?%s" % (MODRINTH, net.quote(project_id), urllib.parse.urlencode(params))
    try:
        versions = net.get_json(url)
    except Exception:  # noqa: BLE001
        return None
    loaders = set()
    for version in versions or []:
        for loader_name in version.get("loaders") or []:
            loaders.add(str(loader_name).lower())
    _avail_cache[key] = (now, loaders)
    return loaders


def search(loader, mc_id, query="", page=1, per_page=PER_PAGE, kind=KIND_MOD):
    """Каталог модов/шейдеров с постраничной выдачей (максимум MAX_ITEMS позиций).

    Наличие файла проверяется по API версий проекта, поэтому «Недоступно» ставится
    только тогда, когда под эту версию файла действительно нет.
    """
    if not supports_kind(kind, loader):
        return {"available": False, "error": "unavailable", "hits": [], "page": 1, "pages": 0,
                "total": 0, "kind": kind}
    facets, target = _facets(kind, loader)
    page = max(1, int(page or 1))
    per_page = max(1, min(int(per_page or PER_PAGE), MAX_ITEMS))
    offset = (page - 1) * per_page
    limit = min(per_page, MAX_ITEMS - offset)
    if limit <= 0:
        return {"available": True, "error": None, "hits": [], "page": page, "pages": 0,
                "perPage": per_page, "total": MAX_ITEMS, "matching": 0, "checked": 0,
                "loaderName": target, "gameVersion": mc_id, "kind": kind}
    params = {
        "facets": _json_param(facets),
        "limit": str(limit),
        "offset": str(offset),
        "index": "downloads",
    }
    if query:
        params["query"] = query
    url = "%s/search?%s" % (MODRINTH, urllib.parse.urlencode(params))
    try:
        data = net.get_json(url)
    except Exception as exc:  # noqa: BLE001
        return {"available": True, "error": str(exc), "hits": [], "page": page, "pages": 0,
                "total": 0, "kind": kind}
    total_found = int(data.get("total_hits") or 0)
    total = min(total_found, MAX_ITEMS)
    hits = []
    matching = 0
    checked = 0
    raw_hits = data.get("hits") or []
    project_ids = [hit.get("project_id") or hit.get("slug") for hit in raw_hits]
    loader_map = {}
    if project_ids:
        with ThreadPoolExecutor(max_workers=10) as pool:
            results = list(pool.map(lambda pid: availability(pid, mc_id, kind), project_ids))
        loader_map = dict(zip(project_ids, results))
    for hit in raw_hits:
        versions = [str(v) for v in (hit.get("versions") or [])]
        versions.sort(key=_version_key, reverse=True)
        project_id = hit.get("project_id") or hit.get("slug")
        loaders = loader_map.get(project_id)
        available_loaders = []
        verified = False
        if loaders is not None:
            verified = True
            checked += 1
            if kind == KIND_SHADER:
                supported = bool(loaders)
            else:
                supported = target in loaders
            available_loaders = sorted(name for name in loaders if name in MOD_LOADER_NAMES)
        else:
            supported = (not versions) or (mc_id in versions)
        if supported:
            matching += 1
        hits.append({
            "id": project_id,
            "slug": hit.get("slug"),
            "title": hit.get("title"),
            "description": hit.get("description"),
            "author": hit.get("author"),
            "downloads": hit.get("downloads") or 0,
            "icon": hit.get("icon_url"),
            "url": "https://modrinth.com/%s/%s" % ("shader" if kind == KIND_SHADER else "mod",
                                                   hit.get("slug") or project_id),
            "versions": versions,
            "supports": supported,
            "verified": verified,
            "availableLoaders": available_loaders,
        })
    pages = max(1, (total + per_page - 1) // per_page) if total else 1
    return {
        "available": True,
        "error": None,
        "hits": hits,
        "page": page,
        "pages": pages,
        "perPage": per_page,
        "total": total,
        "totalFound": total_found,
        "matching": matching,
        "checked": checked,
        "loaderName": target,
        "gameVersion": mc_id,
        "kind": kind,
    }


def no_build_message(project_id, loader, mc_id, kind=KIND_MOD):
    """Понятная причина: под какую версию/загрузчик файла нет и где он есть."""
    if kind == KIND_SHADER:
        loaders = availability(project_id, mc_id, kind) or set()
        text = "У этого шейдера нет сборки под Minecraft %s." % mc_id
        if not loaders:
            text += " Проверьте версию игры в карточке шейдера."
        return text
    target = modrinth_loader(loader)
    loaders = availability(project_id, mc_id, kind) or set()
    others = [MOD_LOADER_NAMES[name] for name in sorted(loaders)
              if name != target and name in MOD_LOADER_NAMES]
    text = "У этого мода нет сборки под %s для %s." % (mc_id, MOD_LOADER_NAMES.get(target, target.capitalize()))
    if others:
        text += " Для этой версии он есть на: %s — выберите этот загрузчик." % ", ".join(others)
    else:
        text += " Под эту версию сборки нет ни у одного загрузчика."
    return text


def install(project_id, loader, mc_id, dest_dir, progress=None, kind=KIND_MOD):
    requested = ["optifine"] if kind == KIND_SHADER else [modrinth_loader(loader)]
    params = {
        "loaders": _json_param(requested),
        "game_versions": _json_param([mc_id]),
    }
    url = "%s/project/%s/version?%s" % (MODRINTH, net.quote(project_id), urllib.parse.urlencode(params))
    versions = net.get_json(url)
    if not versions:
        raise RuntimeError(no_build_message(project_id, loader, mc_id, kind))
    version = versions[0]
    files = version.get("files") or []
    primary = None
    for item in files:
        if item.get("primary"):
            primary = item
            break
    primary = primary or (files[0] if files else None)
    if not primary or not primary.get("url"):
        raise RuntimeError("У этой версии нет файла для скачивания")
    os.makedirs(dest_dir, exist_ok=True)
    filename = primary.get("filename") or os.path.basename(primary["url"])
    dest = os.path.join(dest_dir, filename)
    if progress:
        progress.set_stage("shaders" if kind == KIND_SHADER else "mods",
                           "Скачивание %s %s" % ("шейдера" if kind == KIND_SHADER else "мода", filename))
        progress.plan(1, primary.get("size") or 0)
    errors = net.download_many([{
        "url": primary["url"], "dest": dest,
        "sha1": (primary.get("hashes") or {}).get("sha1"),
        "size": primary.get("size"),
    }], progress, threads=1)
    if errors:
        raise RuntimeError("Файл не скачался: " + errors[0])
    return {"file": filename, "path": dest, "version": version.get("version_number"),
            "name": version.get("name") or filename}


def installed(directory, kind=KIND_MOD):
    if not os.path.isdir(directory):
        return []
    ext = ".zip" if kind == KIND_SHADER else ".jar"
    result = []
    for name in sorted(os.listdir(directory)):
        if not name.lower().endswith(ext):
            continue
        path = os.path.join(directory, name)
        result.append({"file": name, "size": os.path.getsize(path)})
    return result


def remove(directory, filename):
    path = os.path.join(directory, os.path.basename(filename))
    if os.path.exists(path):
        os.remove(path)
        return True
    return False
