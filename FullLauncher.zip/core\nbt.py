"""Минимальный NBT: чтение и запись servers.dat (список серверов Minecraft)."""

import gzip
import io
import os
import struct

TAG_END = 0
TAG_BYTE = 1
TAG_SHORT = 2
TAG_INT = 3
TAG_LONG = 4
TAG_FLOAT = 5
TAG_DOUBLE = 6
TAG_BYTE_ARRAY = 7
TAG_STRING = 8
TAG_LIST = 9
TAG_COMPOUND = 10
TAG_INT_ARRAY = 11
TAG_LONG_ARRAY = 12


def _read_utf(stream):
    length = struct.unpack(">H", stream.read(2))[0]
    return stream.read(length).decode("utf-8", "replace")


def _write_utf(out, text):
    raw = str(text).encode("utf-8")
    out += struct.pack(">H", len(raw) & 0xFFFF)
    out += raw


def _read_payload(stream, tag):
    if tag == TAG_BYTE:
        return struct.unpack(">b", stream.read(1))[0]
    if tag == TAG_SHORT:
        return struct.unpack(">h", stream.read(2))[0]
    if tag == TAG_INT:
        return struct.unpack(">i", stream.read(4))[0]
    if tag == TAG_LONG:
        return struct.unpack(">q", stream.read(8))[0]
    if tag == TAG_FLOAT:
        return struct.unpack(">f", stream.read(4))[0]
    if tag == TAG_DOUBLE:
        return struct.unpack(">d", stream.read(8))[0]
    if tag == TAG_BYTE_ARRAY:
        size = struct.unpack(">i", stream.read(4))[0]
        return list(stream.read(max(0, size)))
    if tag == TAG_STRING:
        return _read_utf(stream)
    if tag == TAG_LIST:
        elem_tag = stream.read(1)[0]
        size = struct.unpack(">i", stream.read(4))[0]
        if elem_tag == TAG_END:
            return (TAG_END, [])
        return (elem_tag, [_read_payload(stream, elem_tag) for _ in range(max(0, size))])
    if tag == TAG_COMPOUND:
        result = {}
        while True:
            child = stream.read(1)[0]
            if child == TAG_END:
                break
            name = _read_utf(stream)
            result[name] = (child, _read_payload(stream, child))
        return result
    if tag == TAG_INT_ARRAY:
        size = struct.unpack(">i", stream.read(4))[0]
        return [struct.unpack(">i", stream.read(4))[0] for _ in range(max(0, size))]
    if tag == TAG_LONG_ARRAY:
        size = struct.unpack(">i", stream.read(4))[0]
        return [struct.unpack(">q", stream.read(8))[0] for _ in range(max(0, size))]
    raise ValueError("Неизвестный тег NBT: %r" % tag)


def _write_payload(out, tag, value):
    if tag == TAG_BYTE:
        out += struct.pack(">b", int(value))
    elif tag == TAG_SHORT:
        out += struct.pack(">h", int(value))
    elif tag == TAG_INT:
        out += struct.pack(">i", int(value))
    elif tag == TAG_LONG:
        out += struct.pack(">q", int(value))
    elif tag == TAG_FLOAT:
        out += struct.pack(">f", float(value))
    elif tag == TAG_DOUBLE:
        out += struct.pack(">d", float(value))
    elif tag == TAG_BYTE_ARRAY:
        out += struct.pack(">i", len(value))
        out += bytes(bytearray(int(b) & 0xFF for b in value))
    elif tag == TAG_STRING:
        _write_utf(out, value)
    elif tag == TAG_LIST:
        elem_tag, items = value
        out.append(elem_tag)
        out += struct.pack(">i", len(items))
        for item in items:
            _write_payload(out, elem_tag, item)
    elif tag == TAG_COMPOUND:
        for name, (child_tag, child_value) in value.items():
            out.append(child_tag)
            _write_utf(out, name)
            _write_payload(out, child_tag, child_value)
        out.append(TAG_END)
    elif tag == TAG_INT_ARRAY:
        out += struct.pack(">i", len(value))
        for item in value:
            out += struct.pack(">i", int(item))
    elif tag == TAG_LONG_ARRAY:
        out += struct.pack(">i", len(value))
        for item in value:
            out += struct.pack(">q", int(item))
    else:
        raise ValueError("Неизвестный тег NBT: %r" % tag)


def parse(data):
    stream = io.BytesIO(data)
    tag = stream.read(1)[0]
    if tag == TAG_END:
        return tag, "", None
    name = _read_utf(stream)
    return tag, name, _read_payload(stream, tag)


def encode(tag, name, value):
    out = bytearray()
    out.append(tag)
    if tag != TAG_END:
        _write_utf(out, name)
        _write_payload(out, tag, value)
    return bytes(out)


def _decompress(data):
    if data[:2] == b"\x1f\x8b":
        try:
            return gzip.decompress(data)
        except (OSError, EOFError):
            return data
    return data


def servers_path(game_root):
    return os.path.join(game_root, "servers.dat")


def load(path):
    """Список серверов: [{'name','ip','icon','acceptTextures'}]"""
    if not os.path.exists(path):
        return []
    try:
        with open(path, "rb") as f:
            raw = _decompress(f.read())
        tag, _name, value = parse(raw)
    except (OSError, ValueError, IndexError, struct.error):
        return []
    if tag != TAG_COMPOUND or not isinstance(value, dict):
        return []
    listed = value.get("servers")
    if not listed or listed[0] != TAG_LIST:
        return []
    elem_tag, items = listed[1]
    if elem_tag != TAG_COMPOUND:
        return []
    servers = []
    for item in items:
        if not isinstance(item, dict):
            continue
        record = {}
        for key, (child_tag, child_value) in item.items():
            if child_tag == TAG_STRING:
                record[key] = child_value
            elif child_tag == TAG_BYTE:
                record[key] = int(child_value)
        servers.append(record)
    return servers


GZIP_MAGIC = b"\x1f\x8b"


def is_compressed(path):
    """True/False по формату существующего файла, None если файла ещё нет.

    Старые версии Minecraft пишут servers.dat сжатым (gzip), новые (26.x) — простым NBT.
    """
    try:
        with open(path, "rb") as f:
            head = f.read(2)
    except OSError:
        return None
    return head == GZIP_MAGIC


def _build(servers):
    items = []
    for server in servers:
        entry = {
            "ip": (TAG_STRING, str(server.get("ip", ""))),
            "name": (TAG_STRING, str(server.get("name", ""))),
        }
        icon = server.get("icon")
        if icon:
            entry["icon"] = (TAG_STRING, icon)
        entry["hidden"] = (TAG_BYTE, int(server.get("hidden", 0)))
        entry["acceptTextures"] = (TAG_BYTE, int(server.get("acceptTextures", -1)))
        items.append(entry)
    root = {"servers": (TAG_LIST, (TAG_COMPOUND, items))}
    return encode(TAG_COMPOUND, "", root)


def save(path, servers, compressed=None):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if compressed is None:
        compressed = is_compressed(path)
        if compressed is None:
            compressed = False
    payload = _build(servers)
    if compressed:
        payload = gzip.compress(payload)
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(payload)
    os.replace(tmp, path)
    return path


def add_server(path, name, ip, accept_textures=-1, compressed=None):
    """Добавляет сервер в servers.dat, не теряя уже существующие записи."""
    name = (name or "").strip() or ip
    ip = (ip or "").strip()
    if not ip:
        raise ValueError("Пустой адрес сервера")
    servers = load(path)
    for server in servers:
        if str(server.get("ip", "")).strip().lower() == ip.lower():
            if server.get("name") != name or server.get("hidden"):
                server["name"] = name
                server["hidden"] = 0
                save(path, servers, compressed)
                return {"added": False, "already": True, "total": len(servers), "renamed": True}
            return {"added": False, "already": True, "total": len(servers), "renamed": False}
    servers.append({"name": name, "ip": ip, "hidden": 0, "acceptTextures": accept_textures})
    save(path, servers, compressed)
    return {"added": True, "already": False, "total": len(servers), "renamed": False}
