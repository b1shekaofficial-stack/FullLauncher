"""Конфигурация лаунчера."""

import json
import os
import threading

DEFAULTS = {
    "nickname": "",
    "version": "",
    "loader": "vanilla",
    "loader_version": "",
    "ram": 4096,
    "width": 925,
    "height": 530,
    "java_path": "",
    "close_on_launch": False,
    "discord_rpc": True,
    "servers_pinned": [],
}

VALID_NICK = r"^[A-Za-z0-9_]{3,16}$"


class Config:
    def __init__(self, path):
        self.path = path
        self._lock = threading.Lock()
        self.data = dict(DEFAULTS)
        self.load()

    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                stored = json.load(f)
            if isinstance(stored, dict):
                for key, value in stored.items():
                    if key in DEFAULTS:
                        self.data[key] = value
        except (OSError, ValueError):
            pass
        return self.data

    def save(self):
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        with self._lock:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2, ensure_ascii=False)
            os.replace(tmp, self.path)

    def update(self, patch):
        with self._lock:
            for key, value in (patch or {}).items():
                if key in DEFAULTS:
                    self.data[key] = value
        self.save()
        return self.data

    def get(self, key, default=None):
        return self.data.get(key, DEFAULTS.get(key, default))

    def materialize(self):
        """Дописывает в файл отсутствующие ключи со значениями по умолчанию.

        Нужно, чтобы при первом запуске в config.json сразу появился, например,
        "discord_rpc": true — включён по умолчанию, но его видно и можно выключить.
        """
        stored = {}
        try:
            if os.path.exists(self.path):
                with open(self.path, "r", encoding="utf-8") as f:
                    stored = json.load(f) or {}
        except (OSError, ValueError):
            stored = {}
        if not isinstance(stored, dict):
            stored = {}
        missing = [key for key in DEFAULTS if key not in stored]
        if missing:
            self.save()
        return missing
