' Full Launcher — запуск без чёрного окна консоли.
' Двойной клик по этому файлу запускает лаунчер.
Dim fso, shell, baseDir, exePath, py
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
baseDir = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = baseDir

py = ""
On Error Resume Next
py = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs\Python\Python312\pythonw.exe"
If Not fso.FileExists(py) Then py = ""
If py = "" Then
  Dim probe
  probe = shell.Exec("cmd /c where pythonw.exe").StdOut.ReadAll()
  If InStr(probe, "pythonw") > 0 Then py = Split(Trim(probe), vbCrLf)(0)
End If
On Error Goto 0

If py = "" Then
  MsgBox "Python не найден. Установите Python 3 и запустите app.py вручную.", 16, "Full Launcher"
Else
  shell.Run """" & py & """ """ & baseDir & "\app.py""", 0, False
End If
