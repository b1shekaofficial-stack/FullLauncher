"""Сетевой слой Full Launcher: загрузки с прогрессом, скоростью и проверкой хэшей."""

import hashlib
import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import deque
from concurrent.futures import ThreadPoolExecutor

USER_AGENT = "FullLauncher/1.0 (contact: telegram @FullLauncher)"
CHUNK = 128 * 1024

_opener = urllib.request.build_opener()
_opener.addheaders = [("User-Agent", USER_AGENT), ("Accept", "*/*")]


class NetworkError(RuntimeError):
    pass


def _request(url, timeout=45, headers=None):
    merged = {"User-Agent": USER_AGENT}
    if headers:
        merged.update(headers)
    req = urllib.request.Request(url, headers=merged)
    return _opener.open(req, timeout=timeout)


def get_bytes(url, timeout=45, tries=4):
    last = None
    for attempt in range(tries):
        try:
            with _request(url, timeout) as resp:
                return resp.read()
        except Exception as exc:  # noqa: BLE001
            last = exc
            time.sleep(0.6 * (attempt + 1))
    raise NetworkError("Не удалось скачать %s: %s" % (url, last))


def get_json(url, timeout=45, tries=4):
    raw = get_bytes(url, timeout, tries)
    return json.loads(raw.decode("utf-8", "replace"))


def get_text(url, timeout=45, tries=4):
    return get_bytes(url, timeout, tries).decode("utf-8", "replace")


def quote(value):
    return urllib.parse.quote(value, safe="")


def sha1_of(path, limit=None):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        remaining = limit
        while True:
            size = CHUNK if remaining is None else min(CHUNK, remaining)
            if size <= 0:
                break
            chunk = f.read(size)
            if not chunk:
                break
            h.update(chunk)
            if remaining is not None:
                remaining -= len(chunk)
    return h.hexdigest()


class Progress:
    """Агрегированный прогресс: файлы, байты, скорость. Потокобезопасен."""

    def __init__(self, sink=None):
        self._lock = threading.Lock()
        self.files_total = 0
        self.files_done = 0
        self.bytes_total = 0
        self.bytes_done = 0
        self.stage = "idle"
        self.label = ""
        self.failed = 0
        self.samples = deque(maxlen=30)
        self.sink = sink
        self._last_emit = 0.0

    def reset(self):
        with self._lock:
            self.files_total = 0
            self.files_done = 0
            self.bytes_total = 0
            self.bytes_done = 0
            self.failed = 0
            self.samples.clear()

    def plan(self, files, nbytes):
        with self._lock:
            self.files_total += max(0, files)
            self.bytes_total += max(0, nbytes)

    def set_stage(self, stage, label=""):
        with self._lock:
            self.stage = stage
            if label:
                self.label = label
        self.emit(force=True)

    def add_bytes(self, n):
        with self._lock:
            self.bytes_done += n
        self.emit()

    def file_done(self, failed=False):
        with self._lock:
            self.files_done += 1
            if failed:
                self.failed += 1
        self.emit()

    def skip_file(self, nbytes=0):
        with self._lock:
            self.files_done += 1
            self.bytes_done += max(0, nbytes)
        self.emit()

    def speed(self):
        now = time.time()
        samples = self.samples
        samples.append((now, self.bytes_done))
        while samples and now - samples[0][0] > 3.0:
            samples.popleft()
        if len(samples) < 2:
            return 0.0
        dt = samples[-1][0] - samples[0][0]
        if dt <= 0:
            return 0.0
        return max(0.0, (samples[-1][1] - samples[0][1]) / dt)

    def snapshot(self):
        with self._lock:
            files_total = self.files_total
            files_done = self.files_done
            bytes_total = self.bytes_total
            bytes_done = self.bytes_done
            stage = self.stage
            label = self.label
            failed = self.failed
        percent = 0.0
        if bytes_total > 0:
            percent = min(99.9, bytes_done * 100.0 / bytes_total)
        elif files_total > 0:
            percent = min(99.9, files_done * 100.0 / files_total)
        return {
            "stage": stage,
            "label": label,
            "filesDone": files_done,
            "filesTotal": files_total,
            "bytesDone": bytes_done,
            "bytesTotal": bytes_total,
            "speed": self.speed(),
            "percent": round(percent, 2),
            "failed": failed,
        }

    def emit(self, force=False):
        if not self.sink:
            return
        now = time.time()
        if not force and now - self._last_emit < 0.2:
            return
        self._last_emit = now
        self.sink(self.snapshot())


class _Stop:
    def __init__(self):
        self.event = threading.Event()

    def __bool__(self):
        return self.event.is_set()


def download_one(url, dest, sha1=None, size=None, progress=None, timeout=60, headers=None):
    os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    part = dest + ".part"
    last = None
    for attempt in range(3):
        try:
            with _request(url, timeout, headers) as resp, open(part, "wb") as f:
                while True:
                    chunk = resp.read(CHUNK)
                    if not chunk:
                        break
                    f.write(chunk)
                    if progress:
                        progress.add_bytes(len(chunk))
            if sha1 and sha1_of(part).lower() != sha1.lower():
                os.remove(part)
                raise NetworkError("контрольная сумма не совпала")
            os.replace(part, dest)
            return True
        except Exception as exc:  # noqa: BLE001
            last = exc
            if os.path.exists(part):
                try:
                    os.remove(part)
                except OSError:
                    pass
            time.sleep(0.4 * (attempt + 1))
    raise NetworkError("Ошибка загрузки %s (%s)" % (os.path.basename(dest), last))


def _is_ready(dest, size=None, sha1=None):
    if not os.path.exists(dest):
        return False
    if size is not None and size >= 0:
        try:
            if os.path.getsize(dest) != size:
                return False
        except OSError:
            return False
    if sha1 and size is None:
        try:
            return sha1_of(dest).lower() == sha1.lower()
        except OSError:
            return False
    return True


def download_many(items, progress=None, threads=8):
    """items: [{'url','dest','sha1','size'}] — качает параллельно, отдаёт список ошибок."""
    todo = []
    for item in items:
        if _is_ready(item["dest"], item.get("size"), item.get("sha1")):
            if progress:
                progress.skip_file(item.get("size") or 0)
            continue
        todo.append(item)
    if not todo:
        return []
    errors = []
    lock = threading.Lock()

    def worker(item):
        try:
            download_one(item["url"], item["dest"], item.get("sha1"), item.get("size"), progress,
                         headers=item.get("headers"))
            if progress:
                progress.file_done()
        except Exception as exc:  # noqa: BLE001
            with lock:
                errors.append(str(exc))
            if progress:
                progress.file_done(failed=True)

    with ThreadPoolExecutor(max_workers=max(1, threads)) as pool:
        list(pool.map(worker, todo))
    return errors
