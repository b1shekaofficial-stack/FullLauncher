/* Full Launcher — интерфейс */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const TG_MAIN = "https://t.me/FullLauncher";
const TG_SERVERS = "https://t.me/Azbu4ka";
const MOD_LOADERS = ["forge", "forgeoptifine", "fabric"];
const SHADER_LOADERS = ["optifine", "forgeoptifine"];

const state = {
  cfg: { nickname: "", version: "", loader: "vanilla", loader_version: "", ram: 4096, width: 925, height: 530 },
  boot: null,
  releases: [],
  latest: null,
  loaderCache: {},
  modal: { open: false, version: "", loader: "vanilla", loaderVersion: "", data: null },
  mods: { available: false, hits: [], installed: [], loading: false, page: 1, pages: 1, query: "" },
  shaders: { available: false, hits: [], installed: [], loading: false, page: 1, pages: 1, query: "" },
  job: "idle",
};

let api = null;
let pollTimer = null;

/* ---------- утилиты ---------- */

function apiReady() {
  const a = window.pywebview && window.pywebview.api;
  return !!(a && typeof a.bootstrap === "function");
}

function call(name, ...args) {
  const a = window.pywebview && window.pywebview.api;
  if (!a) return Promise.reject(new Error("Бэкенд ещё не готов"));
  if (typeof a[name] !== "function") {
    return Promise.reject(new Error("Метод «" + name + "» недоступен в бэкенде"));
  }
  return a[name](...args);
}

async function callJson(name, payload) {
  return call(name, JSON.stringify(payload));
}

function waitForApi(timeoutMs = 12000) {
  return new Promise((resolve, reject) => {
    if (apiReady()) return resolve();
    const started = Date.now();
    const timer = setInterval(() => {
      if (apiReady()) {
        clearInterval(timer);
        resolve();
      } else if (Date.now() - started > timeoutMs) {
        clearInterval(timer);
        reject(new Error("Бэкенд лаунчера не отвечает"));
      }
    }, 60);
  });
}

function fmtBytes(n) {
  n = Number(n) || 0;
  if (n <= 0) return "0 Б";
  const units = ["Б", "КБ", "МБ", "ГБ"];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i += 1; }
  return (i === 0 ? Math.round(v) : v.toFixed(1)) + " " + units[i];
}

function fmtSpeed(n) {
  return n > 0 ? fmtBytes(n) + "/с" : "";
}

function escapeHtml(text) {
  return String(text == null ? "" : text)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function nickValid(value) {
  return /^[A-Za-z0-9_]{3,16}$/.test(String(value || "").trim());
}

function loaderLabel(loader) {
  return {
    vanilla: "Vanilla", forge: "Forge", fabric: "Fabric",
    forgeoptifine: "Forge + OptiFine", optifine: "OptiFine",
  }[loader] || "Vanilla";
}

function toast(text, kind = "info", ms = 4200) {
  const box = $("#toasts");
  const el = document.createElement("div");
  el.className = "toast " + kind;
  el.textContent = text;
  box.appendChild(el);
  setTimeout(() => {
    el.style.transition = "opacity .3s, transform .3s";
    el.style.opacity = "0";
    el.style.transform = "translateY(8px)";
    setTimeout(() => el.remove(), 320);
  }, ms);
}

/* ---------- частицы ---------- */

class ParticleField {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.particles = [];
    this.raf = null;
    this.running = false;
    this.resize = this.resize.bind(this);
    this.loop = this.loop.bind(this);
    window.addEventListener("resize", this.resize);
    this.resize();
    this.seed();
  }

  resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.w = window.innerWidth;
    this.h = window.innerHeight;
    this.canvas.width = this.w * dpr;
    this.canvas.height = this.h * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  seed() {
    const count = Math.max(46, Math.min(90, Math.round((this.w * this.h) / 24000)));
    const palette = ["139,92,246", "34,211,238", "167,139,250", "94,234,212"];
    this.particles = Array.from({ length: count }, () => ({
      x: Math.random() * this.w,
      y: Math.random() * this.h,
      r: 0.8 + Math.random() * 2.4,
      vx: (Math.random() - 0.5) * 0.34,
      vy: -0.12 - Math.random() * 0.4,
      a: 0.18 + Math.random() * 0.55,
      pulse: Math.random() * Math.PI * 2,
      color: palette[Math.floor(Math.random() * palette.length)],
    }));
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.resize();
    if (!this.particles.length) this.seed();
    this.raf = requestAnimationFrame(this.loop);
  }

  stop() {
    this.running = false;
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = null;
    this.ctx.clearRect(0, 0, this.w, this.h);
  }

  loop() {
    if (!this.running) return;
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.w, this.h);
    const t = performance.now() / 1000;

    for (const p of this.particles) {
      p.x += p.vx;
      p.y += p.vy;
      if (p.y < -20) { p.y = this.h + 15; p.x = Math.random() * this.w; }
      if (p.x < -20) p.x = this.w + 15;
      if (p.x > this.w + 20) p.x = -15;

      const glow = 0.6 + 0.4 * Math.sin(t * 1.6 + p.pulse);
      const radius = p.r * (0.85 + glow * 0.35);
      const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, radius * 6);
      grad.addColorStop(0, `rgba(${p.color},${(p.a * glow).toFixed(3)})`);
      grad.addColorStop(1, `rgba(${p.color},0)`);
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(p.x, p.y, radius * 6, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = `rgba(255,255,255,${(p.a * 0.75 * glow).toFixed(3)})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, radius * 0.55, 0, Math.PI * 2);
      ctx.fill();
    }

    for (let i = 0; i < this.particles.length; i += 1) {
      for (let j = i + 1; j < this.particles.length; j += 1) {
        const a = this.particles[i];
        const b = this.particles[j];
        const dx = a.x - b.x;
        const dy = a.y - b.y;
        const dist = Math.hypot(dx, dy);
        if (dist < 130) {
          ctx.strokeStyle = `rgba(139,92,246,${(0.16 * (1 - dist / 130)).toFixed(3)})`;
          ctx.lineWidth = 0.7;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.stroke();
        }
      }
    }

    this.raf = requestAnimationFrame(this.loop);
  }
}

let particles = null;

/* ---------- экран загрузки ---------- */

function showOverlay(title, sub) {
  const overlay = $("#launchOverlay");
  overlay.classList.remove("closing");
  overlay.classList.add("open");
  $("#launchTitle").textContent = title || "Full Launcher";
  $("#launchSub").textContent = sub || "";
  $("#launchFill").style.width = "0%";
  $("#launchFiles").textContent = "—";
  $("#launchSpeed").textContent = "";
  if (particles) particles.start();
}

function hideOverlay(delay = 0) {
  const finish = () => {
    const overlay = $("#launchOverlay");
    overlay.classList.add("closing");
    setTimeout(() => {
      overlay.classList.remove("open", "closing");
      if (particles) particles.stop();
    }, 520);
  };
  if (delay > 0) setTimeout(finish, delay); else finish();
}

function setOverlayProgress(percent, filesText, speedText, subText) {
  $("#launchFill").style.width = Math.max(0, Math.min(100, percent)) + "%";
  if (filesText != null) $("#launchFiles").textContent = filesText;
  if (speedText != null) $("#launchSpeed").textContent = speedText;
  if (subText) $("#launchSub").textContent = subText;
}

/* ---------- прогресс внизу ---------- */

function renderBottomProgress(snap) {
  const fill = $("#dlFill");
  const files = $("#dlFiles");
  const speed = $("#dlSpeed");
  if (!snap) {
    fill.style.width = "0%";
    files.textContent = "Готов к запуску";
    speed.textContent = "";
    return;
  }
  fill.style.width = Math.max(0, Math.min(100, snap.percent || 0)) + "%";
  const done = snap.filesDone || 0;
  const total = snap.filesTotal || 0;
  files.textContent = total ? `${done} из ${total} файлов · ${Math.round(snap.percent || 0)}%` : (snap.label || "Подготовка…");
  speed.textContent = fmtSpeed(snap.speed || 0);
}

/* ---------- конфиг и подписи ---------- */

function clientTitle() {
  const cfg = state.cfg;
  if (!cfg.version) return "Выберите версию";
  const loader = cfg.loader || "vanilla";
  let title = cfg.version;
  if (loader !== "vanilla") {
    title += " · " + (loader === "forgeoptifine" ? "Forge+OF" : loaderLabel(loader));
    if (cfg.loader_version && loader !== "forgeoptifine" && loader !== "optifine") {
      title += " " + cfg.loader_version;
    }
  }
  return title;
}

function renderClient() {
  const btn = $("#clientBtn");
  $("#clientName").textContent = clientTitle();
  btn.classList.toggle("missing", !state.cfg.version);
  const modsAvailable = MOD_LOADERS.includes(state.cfg.loader) && !!state.cfg.version;
  $("#modsSub").textContent = modsAvailable
    ? `Каталог Modrinth · Minecraft ${state.cfg.version} · ${loaderLabel(state.cfg.loader)}`
    : "Каталог Modrinth под ваш клиент";
  renderModsGate();
  renderShadersGate();
}

function renderNick() {
  const nick = state.cfg.nickname || "";
  const ok = nickValid(nick);
  $("#nickCheck").classList.toggle("show", ok);
  $("#setNickCheck").classList.toggle("show", ok);
  $("#nickWrap").classList.toggle("invalid", nick.length > 0 && !ok);
  if ($("#nickInput").value !== nick) $("#nickInput").value = nick;
  if ($("#setNick").value !== nick) $("#setNick").value = nick;
  $("#nickWrap").classList.toggle("ok", ok);
}

async function saveConfig(patch, silent = true) {
  Object.assign(state.cfg, patch);
  renderNick();
  renderClient();
  try {
    const res = await callJson("set_config", patch);
    if (res && res.ok) state.cfg = Object.assign(state.cfg, res.config);
  } catch (err) {
    if (!silent) toast("Не удалось сохранить настройки", "err");
  }
}

/* ---------- серверы и новости ---------- */

function renderServers() {
  const list = $("#serverList");
  const servers = (state.boot && state.boot.servers) || [];
  list.innerHTML = "";
  if (!servers.length) {
    list.classList.add("empty");
    list.innerHTML = '<div class="servers-empty"><b>Пока что нету еще…</b></div>';
    return;
  }
  list.classList.remove("empty");
  servers.forEach((server) => {
    const el = document.createElement("div");
    el.className = "server" + (server.hit ? " hit" : "");
    const initials = (server.name || "?").slice(0, 2).toUpperCase();
    const avatar = server.avatar
      ? `<img class="server-ava" src="../assets/${server.avatar}" alt="${escapeHtml(server.name || "")}">`
      : `<span class="server-ico" style="background:linear-gradient(135deg,${server.color || "#8b5cf6"},${(server.color || "#8b5cf6")}99)">${escapeHtml(initials)}</span>`;
    el.innerHTML = `
      ${server.hit ? '<span class="server-hit">ХИТ 👑</span>' : ""}
      <div class="server-row">
        ${avatar}
        <div class="server-main">
          <div class="server-name">${escapeHtml(server.name)} <em class="server-tag">${escapeHtml(server.tag || "Сервер")}</em></div>
          <div class="server-meta">
            <span class="server-ip">${escapeHtml(server.ip)}</span>
            ${server.versions ? `<span class="server-vereq">${escapeHtml(server.versions)}</span>` : ""}
          </div>
        </div>
      </div>
      ${server.note ? `<p class="server-note">${escapeHtml(server.note)}</p>` : ""}
      <div class="server-foot">
        <span class="server-state">${server.installed ? "Уже в Minecraft" : ""}</span>
        <button class="server-add${server.installed ? " done" : ""}">${server.installed ? "Добавлено" : "Добавить"}</button>
      </div>`;
    const btn = el.querySelector(".server-add");
    if (!server.installed) {
      btn.addEventListener("click", () => addServerToMinecraft(server, btn));
    }
    list.appendChild(el);
  });
}

async function addServerToMinecraft(server, btn) {
  if (btn.classList.contains("loading")) return;
  const original = btn.textContent;
  btn.classList.add("loading");
  btn.textContent = "Добавляю…";
  try {
    const res = await call("add_server", server.name, server.ip);
    if (!res || !res.ok) throw new Error((res && res.error) || "не удалось записать servers.dat");
    btn.classList.remove("loading");
    btn.classList.add("done");
    btn.textContent = res.already ? "Уже добавлен" : "Добавлено";
    if (res.servers && state.boot) state.boot.servers = res.servers;
    toast(`«${server.name}» добавлен в Minecraft — он появится в списке серверов`, "ok", 4200);
  } catch (err) {
    btn.classList.remove("loading");
    btn.textContent = original;
    toast("Сервер не добавлен: " + err.message, "err", 6000);
  }
}

function newsItemHtml(item) {
  if (item.featured) {
    return `<button class="news-item featured" data-news="${escapeHtml(item.title)}">
      <div class="cover" style="background-image:url('../assets/${escapeHtml(item.cover || "news-cover.jpg")}')"></div>
      <div class="body">
        <div class="meta"><span class="tag">${escapeHtml(item.tag)}</span><span class="date">${escapeHtml(item.date)}</span></div>
        <h4>${escapeHtml(item.title)}</h4>
        <p>${escapeHtml(item.text)}</p>
      </div>
    </button>`;
  }
  return `<button class="news-item" data-news="${escapeHtml(item.title)}">
    <div class="meta"><span class="tag">${escapeHtml(item.tag)}</span><span class="date">${escapeHtml(item.date)}</span></div>
    <h4>${escapeHtml(item.title)}</h4>
    <p>${escapeHtml(item.text)}</p>
  </button>`;
}

function renderNews() {
  const news = (state.boot && state.boot.news) || [];
  $("#homeNews").innerHTML = news.map(newsItemHtml).join("");
  $("#newsPage").innerHTML = news.map((item) => `
    <article class="news-card${item.featured ? " big" : ""}">
      ${item.featured ? `<div class="cover" style="background-image:url('../assets/${escapeHtml(item.cover || "news-cover.jpg")}')"></div>` : ""}
      <div class="body">
        <div class="meta"><span class="news-item"><span class="tag">${escapeHtml(item.tag)}</span></span></div>
        <div class="meta" style="margin-top:8px"><span class="date">${escapeHtml(item.date)}</span></div>
        <h3>${escapeHtml(item.title)}</h3>
        <p>${escapeHtml(item.text)}</p>
      </div>
    </article>`).join("");
}

/* ---------- клиенты ---------- */

function renderClients() {
  const grid = $("#clientsGrid");
  const releases = state.releases || [];
  $("#clientsSub").textContent = releases.length
    ? `Всего версий: ${releases.length} — от 1.7.10 до ${state.latest || releases[0].id}`
    : "Список версий загружается…";
  grid.innerHTML = releases.map((item) => `
    <button class="client-card${item.recommended ? " top" : ""}" data-version="${escapeHtml(item.id)}">
      <span class="cc-id">${escapeHtml(item.id)}</span>
      <span class="cc-meta">${item.recommended ? "Рекомендуем · " : ""}${escapeHtml(item.released)}</span>
      <span class="cc-arrow">Выбрать →</span>
    </button>`).join("");
  $$(".client-card", grid).forEach((card) => {
    card.addEventListener("click", () => openVersionModal(card.dataset.version));
  });
}

/* ---------- модалка выбора клиента ---------- */

function renderVersionList() {
  const list = $("#verList");
  const query = ($("#verSearch").value || "").trim().toLowerCase();
  const items = (state.releases || []).filter((v) => !query || v.id.toLowerCase().includes(query));
  list.innerHTML = items.map((item) => `
    <button class="ver-row${item.id === state.modal.version ? " active" : ""}" data-id="${escapeHtml(item.id)}">
      <span class="v-id">${escapeHtml(item.id)}</span>
      ${item.recommended ? '<span class="rec">top</span>' : ""}
      <span class="v-date">${escapeHtml(item.released)}</span>
    </button>`).join("");
  $$(".ver-row", list).forEach((row) => {
    row.addEventListener("click", () => selectModalVersion(row.dataset.id));
  });
}

async function selectModalVersion(id) {
  state.modal.version = id;
  state.modal.loaderVersion = "";
  renderVersionList();
  $("#vcTitle").textContent = id;
  $("#vcMeta").textContent = "Загрузка списка модификаций…";
  $("#loaderGrid").innerHTML = "";
  $("#buildRow").classList.add("hidden");
  $("#loaderHint").textContent = "";
  $("#vcStatus").textContent = "";
  let data = state.loaderCache[id];
  if (!data) {
    try {
      data = await call("loaders_for", id);
      state.loaderCache[id] = data;
    } catch (err) {
      data = { ok: false, fabric: [], forge: [], optifine: false };
    }
  }
  if (state.modal.version !== id) return;
  state.modal.data = data;
  const forgeCount = (data.forge || []).length;
  const fabricCount = (data.fabric || []).length;
  const optifineOk = data.optifineSupported !== false;
  const forgeOptOk = data.forgeOptifineSupported !== false;
  const optifineNote = optifineOk
    ? (data.optifine ? "файл найден" : "сборка есть")
    : `нет сборки${data.optifineLatest ? ` (до ${data.optifineLatest})` : ""}`;
  $("#vcMeta").textContent = `Forge: ${forgeCount} сборок · Fabric: ${fabricCount} · OptiFine: ${optifineNote}`;
  if (state.modal.loader === "vanilla" || !MOD_LOADERS.concat("optifine").includes(state.modal.loader)) {
    state.modal.loader = "vanilla";
  }
  const disabled = {
    forge: forgeCount === 0,
    fabric: fabricCount === 0,
    forgeoptifine: !forgeOptOk,
    optifine: !optifineOk,
    vanilla: false,
  };
  if (disabled[state.modal.loader]) state.modal.loader = "vanilla";
  const entries = [
    ["vanilla", "Vanilla", "Чистая версия Minecraft"],
    ["forge", "Forge", forgeCount ? `Последняя: ${data.forge[0]}` : "Нет сборок под эту версию"],
    ["fabric", "Fabric", fabricCount ? `Последняя: ${data.fabric[0]}` : "Нет сборок под эту версию"],
    ["forgeoptifine", "Forge + OptiFine", forgeOptOk
      ? "Forge и шейдеры OptiFine"
      : (data.forgeOptifineReason || "Нет сборки под эту версию")],
    ["optifine", "OptiFine", optifineOk
      ? (data.optifineFile ? "Файл уже скачан" : "Скачается автоматически")
      : (data.optifineLatest ? `Нет сборки, есть до ${data.optifineLatest}` : "Нет сборки под эту версию")],
  ];
  $("#loaderGrid").innerHTML = entries.map(([key, name, hint]) => `
    <button class="loader-card${state.modal.loader === key ? " active" : ""}${disabled[key] ? " off" : ""}" data-loader="${key}">
      <b>${escapeHtml(name)}</b><span>${escapeHtml(hint)}</span>
    </button>`).join("");
  $$(".loader-card").forEach((card) => {
    card.addEventListener("click", () => {
      if (card.classList.contains("off")) {
        toast("Этот загрузчик недоступен для выбранной версии", "warn");
        return;
      }
      state.modal.loader = card.dataset.loader;
      state.modal.loaderVersion = "";
      $$(".loader-card").forEach((c) => c.classList.toggle("active", c === card));
      renderBuildSelect();
      updateLoaderHint();
    });
  });
  renderBuildSelect();
  updateLoaderHint();
}

function renderBuildSelect() {
  const wrap = $("#buildRow");
  const select = $("#loaderBuild");
  const loader = state.modal.loader;
  const data = state.modal.data || {};
  let options = [];
  if (loader === "forge" || loader === "forgeoptifine") options = data.forge || [];
  if (loader === "fabric") options = data.fabric || [];
  if (!options.length) {
    wrap.classList.add("hidden");
    return;
  }
  wrap.classList.remove("hidden");
  select.innerHTML = options.map((v) => `<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join("");
  state.modal.loaderVersion = options[0];
  select.value = options[0];
  select.onchange = () => { state.modal.loaderVersion = select.value; };
}

function updateLoaderHint() {
  const hint = $("#loaderHint");
  const loader = state.modal.loader;
  const data = state.modal.data || {};
  hint.classList.remove("warn");
  if (loader === "vanilla") {
    hint.textContent = "Чистый Minecraft без модов и оптимизаций.";
  } else if (loader === "forge") {
    hint.textContent = "Forge нужен для большинства модов. Установка идёт официальным установщиком Forge.";
  } else if (loader === "fabric") {
    hint.textContent = "Fabric — лёгкий загрузчик модов и основа для Sodium-оптимизаций.";
  } else if (loader === "forgeoptifine") {
    if (data.forgeOptifineSupported === false) {
      hint.classList.add("warn");
      hint.textContent = (data.forgeOptifineReason || "Forge + OptiFine недоступен для этой версии")
        + ". Выберите Forge без OptiFine или другую версию игры.";
    } else {
      hint.textContent = "Forge + OptiFine: лаунчер сам поставит Forge и скачает OptiFine — ничего класть в папки не нужно.";
    }
  } else if (loader === "optifine") {
    if (data.optifineSupported === false) {
      hint.classList.add("warn");
      hint.textContent = `OptiFine не выпущен для ${state.modal.version}`
        + (data.optifineLatest ? ` — последняя версия ${data.optifineLatest}.` : ".");
    } else {
      hint.textContent = "OptiFine скачается автоматически и подключится как мод к Forge — файлы от вас не нужны.";
    }
  }
}

async function openVersionModal(presetVersion) {
  if (state.job === "running") {
    toast("Дождитесь окончания установки", "warn");
    return;
  }
  $("#versionModal").classList.add("open");
  state.modal.open = true;
  if (!state.releases.length) {
    await loadVersions();
  }
  const initial = presetVersion || state.cfg.version || (state.releases[0] && state.releases[0].id);
  state.modal.loader = state.cfg.loader || "vanilla";
  state.modal.loaderVersion = "";
  $("#verSearch").value = "";
  renderVersionList();
  if (initial) await selectModalVersion(initial);
}

function closeVersionModal() {
  $("#versionModal").classList.remove("open");
  state.modal.open = false;
}

async function applyVersionChoice() {
  const loader = state.modal.loader;
  const patch = {
    version: state.modal.version,
    loader,
    loader_version: state.modal.loaderVersion || "",
  };
  await saveConfig(patch, false);
  renderClient();
  closeVersionModal();
  toast(`Клиент: ${clientTitle()}`, "ok", 2600);
  renderModsGate();
  renderShadersGate();
  if (MOD_LOADERS.includes(loader)) loadMods("", 1);
  if (SHADER_LOADERS.includes(loader)) loadShaders("", 1);
}

/* ---------- моды ---------- */

function renderModsGate() {
  const cfg = state.cfg;
  const available = !!cfg.version && MOD_LOADERS.includes(cfg.loader);
  $("#modsLocked").classList.toggle("show", !available);
  $("#modsBody").classList.toggle("show", available);
  state.mods.available = available;
  if (available) {
    const sub = `Minecraft ${cfg.version} · ${loaderLabel(cfg.loader)}`;
    $("#modsSub").textContent = sub;
  }
}

function modVersionsLabel(mod) {
  const list = mod.versions || [];
  if (!list.length) return "";
  const showed = list.slice(0, 6).join(", ");
  return list.length > 6 ? `${showed} и ещё ${list.length - 6}` : showed;
}

function modLoaderName(id) {
  return { forge: "Forge", fabric: "Fabric", neoforge: "NeoForge", quilt: "Quilt", forgeoptifine: "Forge" }[id] || id;
}

function modCardHtml(mod) {
  const icon = mod.icon
    ? `<img class="mod-ico" src="${escapeHtml(mod.icon)}" onerror="this.style.display='none'">`
    : `<span class="mod-ico" style="display:grid;place-items:center;font-weight:700">${escapeHtml((mod.title || "?").slice(0, 1))}</span>`;
  const downloads = mod.downloads > 1000 ? `${(mod.downloads / 1000).toFixed(0)}K` : String(mod.downloads || 0);
  const supported = mod.supports !== false;
  const versions = modVersionsLabel(mod);
  const otherLoaders = (mod.availableLoaders || []).map(modLoaderName);
  let versionsLine;
  if (supported) {
    versionsLine = `Сборка под ${escapeHtml(state.cfg.version)} есть`;
  } else if (otherLoaders.length) {
    versionsLine = `Есть для ${escapeHtml(state.cfg.version)}, но только на ${escapeHtml(otherLoaders.join(" / "))}`;
  } else if (versions) {
    versionsLine = `Есть для: ${escapeHtml(versions)}`;
  } else {
    versionsLine = "Под эту версию сборки нет";
  }
  const action = supported
    ? `<button class="install-btn" data-install="${escapeHtml(mod.id)}">Установить</button>`
    : `<button class="install-btn off" disabled title="Нет сборки под Minecraft ${escapeHtml(state.cfg.version)} для ${escapeHtml(loaderLabel(state.cfg.loader))}">Недоступно</button>`;
  return `<article class="mod-card${supported ? "" : " off"}" data-id="${escapeHtml(mod.id)}">
    <div class="mod-top">${icon}
      <div><div class="mod-name">${escapeHtml(mod.title)}</div>
      <div class="mod-author">${escapeHtml(mod.author || "")}</div></div>
    </div>
    <p class="mod-desc">${escapeHtml(mod.description || "")}</p>
    <div class="mod-vers${supported ? "" : " no"}">${versionsLine}</div>
    <div class="mod-foot"><span class="mod-dl">↓ ${escapeHtml(downloads)}</span>
      ${action}
    </div>
  </article>`;
}

function renderInstalled(installed) {
  state.mods.installed = installed || [];
  $("#installedCount").textContent = state.mods.installed.length ? `${state.mods.installed.length} шт.` : "";
  const list = $("#installedList");
  if (!state.mods.installed.length) {
    list.innerHTML = '<div class="install-empty">Пока пусто — поставьте первый мод</div>';
    return;
  }
  list.innerHTML = state.mods.installed.map((item) => `
    <div class="installed-item">
      <span title="${escapeHtml(item.file)}">${escapeHtml(item.file)}</span>
      <button data-remove="${escapeHtml(item.file)}" title="Удалить">×</button>
    </div>`).join("");
  $$("[data-remove]", list).forEach((btn) => {
    btn.addEventListener("click", async () => {
      const res = await call("mod_remove", btn.dataset.remove);
      if (res && res.ok) {
        toast("Мод удалён", "ok", 2200);
        loadInstalled();
        refreshInstalledButtons();
      }
    });
  });
}

function refreshInstalledButtons() {
  const names = new Set(state.mods.installed.map((m) => m.file));
  $$("[data-install]").forEach((btn) => {
    const card = btn.closest(".mod-card");
    const id = card ? card.dataset.id : "";
    const installed = state.mods.hits.find((h) => h.id === id);
    if (!installed) return;
    const maybe = Array.from(names).some((n) => n.toLowerCase().includes((installed.slug || "").toLowerCase()));
    if (maybe) {
      btn.textContent = "Установлен";
      btn.classList.add("done");
    }
  });
}

function renderPagerInto(pager, res, unitLabel, onPage) {
  if (!pager) return;
  const pages = res.pages || 0;
  if (pages <= 1) {
    pager.innerHTML = "";
    return;
  }
  const cur = res.page || 1;
  const from = Math.min(Math.max(1, cur - 2), Math.max(1, pages - 4));
  const to = Math.min(pages, from + 4);
  const nums = [];
  for (let i = from; i <= to; i += 1) nums.push(i);
  pager.innerHTML = `
    <button class="pg" data-page="${cur - 1}" ${cur <= 1 ? "disabled" : ""}>‹</button>
    ${from > 1 ? '<span class="pg-dots">…</span>' : ""}
    ${nums.map((n) => `<button class="pg${n === cur ? " active" : ""}" data-page="${n}">${n}</button>`).join("")}
    ${to < pages ? '<span class="pg-dots">…</span>' : ""}
    <button class="pg" data-page="${cur + 1}" ${cur >= pages ? "disabled" : ""}>›</button>
    <span class="pg-info">стр. ${cur} из ${pages} · ${res.total} ${unitLabel}</span>`;
  $$(".pg[data-page]", pager).forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = Number(btn.dataset.page);
      if (target >= 1 && target <= pages && target !== cur) onPage(target);
    });
  });
}

function renderPager(res) {
  renderPagerInto($("#modsPager"), res, "модов", (page) => loadMods(state.mods.query, page));
}

function renderShadersPager(res) {
  renderPagerInto($("#shadersPager"), res, "шейдеров", (page) => loadShaders(state.shaders.query, page));
}

async function loadMods(query, page) {
  if (!state.mods.available) return;
  state.mods.loading = true;
  const q = query === undefined ? (state.mods.query || "") : query;
  const target = Math.max(1, Number(page) || 1);
  state.mods.query = q;
  state.mods.page = target;
  $("#modsGrid").innerHTML = '<div class="install-empty">Загружаю каталог Modrinth…</div>';
  $("#modsPager").innerHTML = "";
  try {
    const res = await callJson("mods_search", {
      version: state.cfg.version,
      loader: state.cfg.loader,
      query: q,
      page: target,
      perPage: 21,
    });
    if (!res || !res.available) {
      renderModsGate();
      return;
    }
    if (res.error) {
      $("#modsGrid").innerHTML = `<div class="install-empty">Не удалось получить каталог: ${escapeHtml(res.error)}</div>`;
      return;
    }
    state.mods.hits = res.hits || [];
    state.mods.pages = res.pages || 1;
    const onPage = state.mods.hits.length;
    const matching = res.matching == null ? onPage : res.matching;
    $("#modsSub").textContent = `Minecraft ${state.cfg.version} · ${loaderLabel(state.cfg.loader)} — `
      + `${res.total || onPage} модов, стр. ${res.page || target} из ${res.pages || 1}, `
      + `подходят ${matching} из ${onPage}`;
    if (!state.mods.hits.length) {
      $("#modsGrid").innerHTML = '<div class="install-empty">Ничего не нашлось — попробуйте другой запрос</div>';
    } else {
      $("#modsGrid").innerHTML = state.mods.hits.map(modCardHtml).join("");
      $$("[data-install]").forEach((btn) => {
        btn.addEventListener("click", () => installMod(btn.dataset.install, btn));
      });
    }
    renderPager(res);
    await loadInstalled();
    refreshInstalledButtons();
  } finally {
    state.mods.loading = false;
  }
}

async function loadInstalled() {
  try {
    const installed = await call("mods_installed");
    renderInstalled(installed || []);
  } catch (err) {
    renderInstalled([]);
  }
}

async function installMod(projectId, btn) {
  const original = btn.textContent;
  btn.classList.add("loading");
  btn.textContent = "Скачиваю…";
  try {
    const res = await callJson("mod_install", {
      id: projectId,
      loader: state.cfg.loader,
      version: state.cfg.version,
    });
    if (!res || !res.ok) throw new Error((res && res.error) || "ошибка");
    btn.classList.remove("loading");
    btn.classList.add("done");
    btn.textContent = "Установлен";
    await loadInstalled();
  } catch (err) {
    btn.classList.remove("loading");
    btn.textContent = original;
    toast("Мод не установился: " + err.message, "err", 5200);
  }
}

/* ---------- шейдеры ---------- */

function renderShadersGate() {
  const cfg = state.cfg;
  const available = !!cfg.version && SHADER_LOADERS.includes(cfg.loader);
  $("#shadersLocked").classList.toggle("show", !available);
  $("#shadersBody").classList.toggle("show", available);
  state.shaders.available = available;
  if (available) {
    $("#shadersSub").textContent = `Minecraft ${cfg.version} · ${loaderLabel(cfg.loader)} — каталог Modrinth`;
  }
}

function renderShadersInstalled(list) {
  state.shaders.installed = list || [];
  $("#shadersInstalledCount").textContent = state.shaders.installed.length
    ? `${state.shaders.installed.length} шт.` : "";
  const box = $("#shadersInstalledList");
  if (!state.shaders.installed.length) {
    box.innerHTML = '<div class="install-empty">Пока пусто — поставьте первый шейдер</div>';
    return;
  }
  box.innerHTML = state.shaders.installed.map((item) => `
    <div class="installed-item">
      <span title="${escapeHtml(item.file)}">${escapeHtml(item.file)}</span>
      <button data-shader-remove="${escapeHtml(item.file)}" title="Удалить">×</button>
    </div>`).join("");
  $$("[data-shader-remove]", box).forEach((btn) => {
    btn.addEventListener("click", async () => {
      const res = await call("mod_remove", btn.dataset.shaderRemove, "shader");
      if (res && res.ok) {
        toast("Шейдер удалён", "ok", 2200);
        loadShadersInstalled();
      }
    });
  });
}

async function loadShadersInstalled() {
  try {
    renderShadersInstalled(await call("mods_installed", "shader") || []);
  } catch (err) {
    renderShadersInstalled([]);
  }
}

function refreshShaderButtons() {
  const names = state.shaders.installed.map((m) => m.file.toLowerCase());
  $$("#shadersGrid .install-btn").forEach((btn) => {
    const card = btn.closest(".mod-card");
    const id = card ? card.dataset.id : "";
    const hit = state.shaders.hits.find((h) => h.id === id);
    if (!hit) return;
    const slug = (hit.slug || "").toLowerCase();
    if (slug && names.some((n) => n.includes(slug))) {
      btn.textContent = "Установлен";
      btn.classList.add("done");
    }
  });
}

async function installShader(projectId, btn) {
  const original = btn.textContent;
  btn.classList.add("loading");
  btn.textContent = "Скачиваю…";
  try {
    const res = await callJson("mod_install", {
      kind: "shader",
      id: projectId,
      loader: state.cfg.loader,
      version: state.cfg.version,
    });
    if (!res || !res.ok) throw new Error((res && res.error) || "ошибка");
    btn.classList.remove("loading");
    btn.classList.add("done");
    btn.textContent = "Установлен";
    await loadShadersInstalled();
    refreshShaderButtons();
  } catch (err) {
    btn.classList.remove("loading");
    btn.textContent = original;
    toast("Шейдер не установился: " + err.message, "err", 6000);
  }
}

async function loadShaders(query, page) {
  if (!state.shaders.available) return;
  state.shaders.loading = true;
  const q = query === undefined ? (state.shaders.query || "") : query;
  const target = Math.max(1, Number(page) || 1);
  state.shaders.query = q;
  state.shaders.page = target;
  $("#shadersGrid").innerHTML = '<div class="install-empty">Загружаю каталог шейдеров…</div>';
  $("#shadersPager").innerHTML = "";
  try {
    const res = await callJson("mods_search", {
      kind: "shader",
      version: state.cfg.version,
      loader: state.cfg.loader,
      query: q,
      page: target,
      perPage: 21,
    });
    if (!res || !res.available) {
      renderShadersGate();
      return;
    }
    if (res.error) {
      $("#shadersGrid").innerHTML = `<div class="install-empty">Не удалось получить каталог: ${escapeHtml(res.error)}</div>`;
      return;
    }
    state.shaders.hits = res.hits || [];
    const onPage = state.shaders.hits.length;
    const matching = res.matching == null ? onPage : res.matching;
    $("#shadersSub").textContent = `Minecraft ${state.cfg.version} · ${loaderLabel(state.cfg.loader)} — `
      + `${res.total || onPage} шейдеров, стр. ${res.page || target} из ${res.pages || 1}, `
      + `подходят ${matching} из ${onPage}`;
    if (!onPage) {
      $("#shadersGrid").innerHTML = '<div class="install-empty">Ничего не нашлось — попробуйте другой запрос</div>';
    } else {
      $("#shadersGrid").innerHTML = state.shaders.hits.map(modCardHtml).join("");
      $$("#shadersGrid [data-install]").forEach((btn) => {
        btn.addEventListener("click", () => installShader(btn.dataset.install, btn));
      });
    }
    renderShadersPager(res);
    await loadShadersInstalled();
    refreshShaderButtons();
  } finally {
    state.shaders.loading = false;
  }
}

/* ---------- Discord Rich Presence ---------- */

function renderRpc(status) {
  const sw = $("#rpcToggle");
  if (!sw || !status) return;
  const enabled = status.enabled !== false;
  sw.classList.toggle("on", enabled);
  sw.setAttribute("aria-pressed", enabled ? "true" : "false");
  if (status.clientId) $("#rpcAppId").textContent = status.clientId;
  const labels = {
    connected: "Подключено",
    connecting: "Подключение к Discord…",
    offline: "Discord не запущен",
    disabled: "Выключено",
    error: "Ошибка подключения",
  };
  const label = labels[status.state] || status.state || "";
  const detail = status.state === "connected" && status.detail ? " · " + status.detail : "";
  if (!enabled) {
    $("#rpcStatus").textContent = "Rich Presence выключен";
    $("#rpcStatus").className = "rpc-status";
    return;
  }
  $("#rpcStatus").textContent = label + detail;
  $("#rpcStatus").className = "rpc-status " + (status.state === "connected" ? "ok" : "wait");
}

async function refreshRpc() {
  try {
    renderRpc(await call("rpc_status"));
  } catch (err) { /* Discord не обязателен */ }
}

async function toggleRpc() {
  const enabled = !$("#rpcToggle").classList.contains("on");
  try {
    const status = await call("set_rpc_enabled", enabled);
    state.cfg.discord_rpc = enabled;
    renderRpc(status);
    toast(enabled ? "Discord Rich Presence включён" : "Discord Rich Presence выключен", "ok", 2400);
  } catch (err) {
    toast("Не удалось переключить Rich Presence: " + err.message, "err", 4000);
  }
}

/* ---------- настройки ---------- */

function renderSettings() {
  const cfg = state.cfg;
  $("#ramRange").value = String(cfg.ram || 4096);
  $("#ramLabel").textContent = `${cfg.ram || 4096} МБ`;
  $("#gameW").value = cfg.width || 925;
  $("#gameH").value = cfg.height || 530;
  $("#gameRootPath").textContent = (state.boot && state.boot.gameRoot) || "";
  const javas = (state.boot && state.boot.java) || [];
  const list = $("#javaList");
  if (!javas.length) {
    list.innerHTML = '<div class="java-item"><span>Java не найдена</span><b>скачаю автоматически</b></div>';
  } else {
    list.innerHTML = javas.map((j) => `<div class="java-item"><span>Java ${j.version} · ${j.source === "runtime" ? "рантайм лаунчера" : "системная"}</span><b>${j.version >= 17 ? "ок" : "старая"}</b></div>`).join("");
  }
  renderRpc({
    enabled: cfg.discord_rpc !== false,
    state: cfg.discord_rpc === false ? "disabled" : "connecting",
    detail: "",
    clientId: "1564259805990756382",
  });
  refreshRpc();
}

/* ---------- запуск ---------- */

async function startGame() {
  if (state.job === "running") return;
  if (!state.cfg.version) {
    openVersionModal();
    toast("Сначала выберите клиент", "warn");
    return;
  }
  if (!nickValid(state.cfg.nickname)) {
    $("#playBtn").classList.add("shake");
    setTimeout(() => $("#playBtn").classList.remove("shake"), 420);
    $("#nickInput").focus();
    toast("Введите ник: 3–16 символов, латиница, цифры, _", "warn");
    return;
  }
  showOverlay("Запускаю " + clientTitle(), "Проверяю файлы игры…");
  setOverlayProgress(0, "0 из 0 файлов", "");
  state.job = "running";
  $("#playBtn").classList.add("busy");
  $("#playLabel").textContent = "Запуск…";
  try {
    const res = await callJson("play", {
      version: state.cfg.version,
      loader: state.cfg.loader,
      loaderVersion: state.cfg.loader_version,
      nickname: state.cfg.nickname,
      ram: state.cfg.ram,
    });
    if (!res || !res.ok) {
      throw new Error((res && res.error) || "не удалось запустить");
    }
  } catch (err) {
    state.job = "idle";
    $("#playBtn").classList.remove("busy");
    $("#playLabel").textContent = "Играть";
    toast(err.message, "err", 6000);
    hideOverlay();
  }
}

/* ---------- события бэкенда ---------- */

function handleEvent(evt) {
  const { type, data } = evt;
  if (type === "progress") {
    renderBottomProgress(data);
    if ($("#launchOverlay").classList.contains("open")) {
      const files = data.filesTotal
        ? `${data.filesDone} из ${data.filesTotal} файлов`
        : "Проверяю файлы";
      setOverlayProgress(data.percent || 0, files, fmtSpeed(data.speed || 0), data.label || null);
    }
  } else if (type === "toast" && data) {
    toast(data.text, data.kind || "info");
  } else if (type === "rpc" && data) {
    renderRpc(Object.assign({ enabled: state.cfg.discord_rpc !== false }, data));
  } else if (type === "log") {
    if ($("#launchOverlay").classList.contains("open")) {
      setOverlayProgress(null, null, null, data.length > 110 ? data.slice(0, 110) + "…" : data);
    }
  } else if (type === "job" && data) {
    if (data.state === "running") {
      state.job = "running";
    } else if (data.state === "launched") {
      state.job = "idle";
      $("#playBtn").classList.remove("busy");
      $("#playLabel").textContent = "Играть";
      setOverlayProgress(100, "Готово", "");
      $("#launchTitle").textContent = "Minecraft запущен";
      $("#launchSub").textContent = data.version ? `Клиент: ${data.version}` : "";
      hideOverlay(900);
      toast("Minecraft запущен. Приятной игры!", "ok", 5000);
      renderBottomProgress(null);
      refreshInstalledClients();
    } else if (data.state === "error") {
      state.job = "idle";
      $("#playBtn").classList.remove("busy");
      $("#playLabel").textContent = "Играть";
      $("#launchTitle").textContent = "Не получилось";
      $("#launchSub").textContent = data.message || "Неизвестная ошибка";
      toast(data.message || "Ошибка запуска", "err", 9000);
      renderBottomProgress(null);
      hideOverlay(6500);
    } else if (data.state === "cancelled") {
      state.job = "idle";
      $("#playBtn").classList.remove("busy");
      $("#playLabel").textContent = "Играть";
      hideOverlay();
      renderBottomProgress(null);
    }
  }
}

async function refreshInstalledClients() {
  try {
    const res = await call("installed_versions");
    if (res) state.installed = res;
  } catch (err) { /* необязательно */ }
}

function startPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(async () => {
    if (!apiReady()) return;
    try {
      const events = await window.pywebview.api.poll();
      (events || []).forEach(handleEvent);
    } catch (err) { /* игнорируем */ }
  }, 180);
}

/* ---------- навигация ---------- */

function setPage(name) {
  $$(".nav-item").forEach((btn) => btn.classList.toggle("active", btn.dataset.page === name));
  $$(".page").forEach((page) => page.classList.toggle("active", page.dataset.page === name));
  if (name === "mods") {
    renderModsGate();
    if (state.mods.available && !state.mods.hits.length) loadMods();
  }
  if (name === "shaders") {
    renderShadersGate();
    if (state.shaders.available && !state.shaders.hits.length) loadShaders();
  }
  if (name === "settings") renderSettings();
}

/* ---------- загрузка версий ---------- */

async function loadVersions() {
  try {
    const res = await call("versions");
    if (res && res.ok) {
      state.releases = res.releases || [];
      state.latest = res.latest;
      renderClients();
    } else if (res && res.error) {
      toast("Не удалось получить список версий: " + res.error, "err", 7000);
    }
  } catch (err) {
    toast("Ошибка списка версий: " + err.message, "err", 7000);
  }
}

/* ---------- инициализация ---------- */

async function boot() {
  particles = new ParticleField($("#particles"));
  showOverlay("Full Launcher", "Читаю манифест версий Minecraft…");
  bindUi();
  await waitForApi();
  try {
    const fast = await call("get_config");
    if (fast && fast.config) {
      state.cfg = Object.assign(state.cfg, fast.config);
      if (fast.gameRoot) $("#gameRootPath").textContent = fast.gameRoot;
      renderNick();
      renderClient();
    }
  } catch (err) { /* не критично: ниже подтянет bootstrap */ }
  try {
    const boot = await call("bootstrap");
    state.boot = boot;
    if (boot.config) state.cfg = Object.assign(state.cfg, boot.config);
    renderNick();
    renderServers();
    renderNews();
    renderClient();
    renderSettings();
    if (!boot.ok) {
      $("#launchTitle").textContent = "Нет связи с Mojang";
      $("#launchSub").textContent = boot.error || "Проверьте интернет";
      toast("Манифест версий недоступен: " + (boot.error || ""), "err", 8000);
      hideOverlay(3200);
    } else {
      setOverlayProgress(100, "Готово", "");
      hideOverlay(420);
    }
    await loadVersions();
    startPolling();
    refreshRpc();
    setInterval(refreshRpc, 12000);
  } catch (err) {
    $("#launchTitle").textContent = "Ошибка запуска";
    $("#launchSub").textContent = err.message;
    hideOverlay(3200);
    startPolling();
  }
}

function bindUi() {
  $$(".nav-item").forEach((btn) => btn.addEventListener("click", () => setPage(btn.dataset.page)));
  $$("[data-page-link]").forEach((btn) => btn.addEventListener("click", () => setPage(btn.dataset.pageLink)));
  $$("[data-tg]").forEach((btn) => btn.addEventListener("click", () => {
    const url = btn.dataset.tg === "servers" ? TG_SERVERS : TG_MAIN;
    call("open_url", url);
  }));
  $$("[data-open-version]").forEach((btn) => btn.addEventListener("click", () => openVersionModal()));
  $$("[data-folder]").forEach((btn) => btn.addEventListener("click", async () => {
    const res = await call("open_folder", btn.dataset.folder);
    if (res && res.path) toast("Папка: " + res.path, "info", 2600);
  }));

  $("#btnMin").addEventListener("click", () => call("minimize"));
  $("#btnClose").addEventListener("click", () => call("close"));

  $("#playBtn").addEventListener("click", startGame);
  $("#clientBtn").addEventListener("click", () => openVersionModal());
  $("#modalClose").addEventListener("click", closeVersionModal);
  $("#modalCancel").addEventListener("click", closeVersionModal);
  $("#vcApply").addEventListener("click", applyVersionChoice);
  $("#verSearch").addEventListener("input", renderVersionList);
  $("#versionModal").addEventListener("click", (evt) => {
    if (evt.target.id === "versionModal") closeVersionModal();
  });

  const onNickInput = (evt) => {
    const value = evt.target.value.replace(/[^A-Za-z0-9_]/g, "").slice(0, 16);
    evt.target.value = value;
    state.cfg.nickname = value;
    $("#nickInput").value = value;
    $("#setNick").value = value;
    renderNick();
    clearTimeout(onNickInput.timer);
    onNickInput.timer = setTimeout(() => saveConfig({ nickname: value }), 380);
  };
  $("#nickInput").addEventListener("input", onNickInput);
  $("#setNick").addEventListener("input", onNickInput);

  $("#ramRange").addEventListener("input", (evt) => {    $("#ramLabel").textContent = evt.target.value + " МБ";
    state.cfg.ram = Number(evt.target.value);
    clearTimeout(window.__ramTimer);
    window.__ramTimer = setTimeout(() => saveConfig({ ram: Number(evt.target.value) }), 300);
  });
  $("#gameW").addEventListener("change", (evt) => saveConfig({ width: Number(evt.target.value) || 925 }));
  $("#gameH").addEventListener("change", (evt) => saveConfig({ height: Number(evt.target.value) || 530 }));

  $("#modSearchBtn").addEventListener("click", () => loadMods($("#modSearch").value, 1));
  $("#modSearch").addEventListener("keydown", (evt) => {
    if (evt.key === "Enter") loadMods($("#modSearch").value, 1);
  });
  $("#shaderSearchBtn").addEventListener("click", () => loadShaders($("#shaderSearch").value, 1));
  $("#shaderSearch").addEventListener("keydown", (evt) => {
    if (evt.key === "Enter") loadShaders($("#shaderSearch").value, 1);
  });

  $("#btnCache").addEventListener("click", async () => {
    await call("clear_cache");
    toast("Кэш версий сброшен", "ok", 2400);
    loadVersions();
  });
  $("#rpcToggle").addEventListener("click", toggleRpc);

  document.addEventListener("keydown", (evt) => {
    if (evt.key === "Escape") {
      if ($("#versionModal").classList.contains("open")) closeVersionModal();
    }
    if (evt.key === "Enter" && $("#versionModal").classList.contains("open")) {
      if (document.activeElement && document.activeElement.id === "verSearch") return;
      applyVersionChoice();
    }
  });

  $("#homeNews").addEventListener("click", (evt) => {
    if (evt.target.closest("[data-news]")) setPage("news");
  });
}

document.addEventListener("DOMContentLoaded", boot);
