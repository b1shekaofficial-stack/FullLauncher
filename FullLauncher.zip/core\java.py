"""Поиск и автоскачивание Java (включая официальные рантаймы Mojang)."""

import glob
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import time

from . import net, mc

RUNTIME_INDEX_URL = (
    "https://launchermeta.mojang.com/v1/products/java-runtime/"
    "2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json"
)
CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0


def _java_exe(directory):
    name = "javaw.exe" if os.name == "nt" else "java"
    path = os.path.join(directory, "bin", name)
    return path if os.path.exists(path) else None


def java_major(exe):
    if not exe or not os.path.exists(exe):
        return 0
    try:
        proc = subprocess.run([exe, "-version"], capture_output=True, text=True,
                              timeout=25, creationflags=CREATE_NO_WINDOW)
        text = (proc.stderr or "") + (proc.stdout or "")
        match = re.search(r'version "(\d+)(?:\.(\d+))?', text)
        if not match:
            return 0
        major = int(match.group(1))
        if major == 1 and match.group(2):
            return int(match.group(2))
        return major
    except (OSError, subprocess.SubprocessError):
        return 0


SEARCH_ROOTS = [
    r"C:\Program Files\Java",
    r"C:\Program Files (x86)\Java",
    r"C:\Program Files\Eclipse Adoptium",
    r"C:\Program Files\Microsoft",
    r"C:\Program Files\Zulu",
    r"C:\Program Files\BellSoft",
    r"C:\Program Files\Amazon Corretto",
    r"C:\Program Files\Semeru",
    r"C:\Program Files\JetBrains",
    os.path.join(os.path.expanduser("~"), ".jdks"),
    os.path.join(os.path.expanduser("~"), ".gradle", "jdks"),
    os.path.join(os.path.expanduser("~"), "scoop", "apps"),
]


def _walk_java_bins(root, max_depth=3):
    root = root.rstrip("\\/")
    if not os.path.isdir(root):
        return
    base_depth = root.count(os.sep)
    for current, dirs, files in os.walk(root):
        depth = current.count(os.sep) - base_depth
        if depth >= max_depth:
            dirs[:] = []
        if ("javaw.exe" in files or "java.exe" in files) and os.path.basename(current).lower() == "bin":
            yield current


def _candidate_dirs():
    dirs = []
    if os.environ.get("JAVA_HOME"):
        dirs.append(os.environ["JAVA_HOME"])
    found = shutil.which("javaw") or shutil.which("java")
    if found:
        candidates = [
            os.path.dirname(found),
            os.path.dirname(os.path.dirname(os.path.realpath(found))),
            os.path.dirname(os.path.dirname(os.path.abspath(found))),
        ]
        for item in candidates:
            if os.path.basename(item).lower() == "bin":
                dirs.append(os.path.dirname(item))
            else:
                dirs.append(item)
    for root in SEARCH_ROOTS:
        for directory in _walk_java_bins(root):
            dirs.append(os.path.dirname(directory))
    return dirs


_detect_cache = {"at": 0.0, "data": []}


def detect(game=None, force=False):
    """Список найденных Java: [{'path','version','label','source'}]"""
    if not force and time.time() - _detect_cache["at"] < 45:
        cached = _detect_cache["data"]
        if not game or any(item["source"] == "runtime" for item in cached) or not os.path.isdir(game.runtime_dir):
            return list(cached)
    seen = set()
    result = []
    if game and os.path.isdir(game.runtime_dir):
        for name in os.listdir(game.runtime_dir):
            directory = os.path.join(game.runtime_dir, name)
            candidate = _java_exe(directory)
            if not candidate:
                candidate = _java_exe(os.path.join(directory, os.path.basename(directory)))
            if not candidate:
                for found in _walk_java_bins(directory, max_depth=2):
                    candidate = _java_exe(os.path.dirname(found))
                    if candidate:
                        break
            if not candidate:
                continue
            path = os.path.realpath(candidate)
            if path in seen:
                continue
            seen.add(path)
            version = java_major(path)
            if not version:
                continue
            result.append({"path": path, "version": version, "source": "runtime",
                           "label": "Mojang runtime · Java %d" % version})
    for directory in _candidate_dirs():
        candidate = _java_exe(directory)
        if not candidate:
            continue
        path = os.path.realpath(candidate)
        if path in seen:
            continue
        version = java_major(path)
        if not version:
            continue
        seen.add(path)
        result.append({"path": path, "version": version, "source": "system",
                       "label": "Java %d · %s" % (version, os.path.basename(os.path.dirname(os.path.dirname(path))))})
    result.sort(key=lambda item: item["version"])
    _detect_cache["at"] = time.time()
    _detect_cache["data"] = result
    return list(result)


def pick(javas, required):
    required = int(required or 8)
    if required <= 8:
        for item in javas:
            if item["version"] == 8:
                return item
        return None
    candidates = [j for j in javas if j["version"] >= required]
    if not candidates:
        return None
    return sorted(candidates, key=lambda item: item["version"])[0]


def _platform_key():
    machine = (platform.machine() or "").lower()
    if "arm" in machine:
        return "windows-arm64" if os.name == "nt" else "linux-arm64"
    if sys.maxsize <= 2 ** 32:
        return "windows-x86" if os.name == "nt" else "linux-i386"
    return "windows-x64" if os.name == "nt" else "linux"


def _runtime_component(index, component, required):
    platform_key = _platform_key()
    available = index.get(platform_key) or {}
    if component and available.get(component):
        return component
    for name, builds in available.items():
        for build in builds or []:
            version_name = str((build.get("version") or {}).get("name") or "")
            match = re.match(r"(\d+)", version_name)
            if match and int(match.group(1)) == int(required):
                return name
    return None


def ensure_runtime(game, component, required, progress=None):
    """Скачивает официальный рантайм Mojang и возвращает путь к javaw.exe."""
    index = net.get_json(RUNTIME_INDEX_URL)
    chosen = _runtime_component(index, component, required)
    if not chosen:
        raise RuntimeError("Не нашёл подходящую Java %d в каталоге Mojang. Установите Java вручную." % required)
    builds = index[_platform_key()][chosen]
    manifest_meta = builds[0]["manifest"]
    manifest = net.get_json(manifest_meta["url"])
    target_root = os.path.join(game.runtime_dir, "%s-%d" % (chosen, required))
    os.makedirs(target_root, exist_ok=True)
    files = (manifest.get("files") or {})
    if progress:
        progress.set_stage("java", "Загрузка Java %d (официальный рантайм Mojang)" % required)
    items = []
    for rel_path, meta in files.items():
        kind = meta.get("type")
        dest = os.path.join(target_root, rel_path.replace("/", os.sep))
        if kind == "directory":
            os.makedirs(dest, exist_ok=True)
            continue
        if kind == "link":
            continue
        raw = (meta.get("downloads") or {}).get("raw")
        if not raw:
            continue
        items.append({"url": raw["url"], "dest": dest,
                      "sha1": raw.get("sha1"), "size": raw.get("size")})
    if progress:
        progress.plan(len(items), sum(i.get("size") or 0 for i in items))
    errors = net.download_many(items, progress, threads=8)
    if errors:
        raise RuntimeError("Java не скачалась: " + errors[0])
    for rel_path, meta in files.items():
        if meta.get("executable"):
            path = os.path.join(target_root, rel_path.replace("/", os.sep))
            if os.path.exists(path):
                try:
                    os.chmod(path, os.stat(path).st_mode | stat.S_IEXEC)
                except OSError:
                    pass
    exe = _java_exe(target_root)
    if not exe:
        raise RuntimeError("В скачанном рантайме нет javaw.exe")
    return exe


def resolve(game, merged, progress=None):
    """Возвращает путь к Java под требования версии (скачивает при необходимости)."""
    java_meta = merged.get("javaVersion") or {}
    required = int(java_meta.get("majorVersion") or 8)
    component = java_meta.get("component")
    javas = detect(game)
    picked = pick(javas, required)
    if picked:
        return picked["path"], picked["version"], False
    try:
        exe = ensure_runtime(game, component, required, progress)
        _detect_cache["at"] = 0.0
        return exe, required, True
    except Exception as exc:  # noqa: BLE001
        fallback = None
        for item in javas:
            if required <= 8 and 8 < item["version"] <= 11:
                fallback = item
                break
            if required > 8 and item["version"] >= required:
                fallback = item
                break
        if fallback:
            if progress:
                progress.set_stage("java", "Скачать Java %d не удалось, беру Java %d"
                                   % (required, fallback["version"]))
            return fallback["path"], fallback["version"], False
        raise RuntimeError("Нет подходящей Java %d и не удалось скачать её: %s"
                           % (required, exc))
