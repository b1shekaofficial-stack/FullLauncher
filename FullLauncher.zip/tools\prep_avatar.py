"""Подготовка аватарки: убираем белые и «пиксельные» края, собираем .ico."""

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from make_icon import box_resize, load_png_rgba, write_png  # noqa: E402

ASSETS = os.path.join(ROOT, "assets")
SIZE = 512
BASE = (10, 10, 18)


def smoothstep(edge0, edge1, x):
    t = max(0.0, min(1.0, (x - edge0) / (edge1 - edge0)))
    return t * t * (3 - 2 * t)


def corner_brightness(width, height, rgba, box=10):
    points = [(0, 0), (width - box, 0), (0, height - box), (width - box, height - box)]
    values = []
    for ox, oy in points:
        total = 0
        count = 0
        for y in range(oy, oy + box):
            for x in range(ox, ox + box):
                i = (y * width + x) * 4
                total += (rgba[i] + rgba[i + 1] + rgba[i + 2]) / 3
                count += 1
        values.append(total / count)
    return values


def blur(width, height, rgba, radius=1):
    src = list(rgba)
    out = bytearray(len(rgba))
    for y in range(height):
        for x in range(width):
            r = g = b = a = n = 0
            for dy in range(-radius, radius + 1):
                yy = min(height - 1, max(0, y + dy))
                for dx in range(-radius, radius + 1):
                    xx = min(width - 1, max(0, x + dx))
                    i = (yy * width + xx) * 4
                    r += src[i]
                    g += src[i + 1]
                    b += src[i + 2]
                    a += src[i + 3]
                    n += 1
            o = (y * width + x) * 4
            out[o] = r // n
            out[o + 1] = g // n
            out[o + 2] = b // n
            out[o + 3] = a // n
    return out


def vignette(width, height, rgba, inner=0.60, outer=1.02):
    cx = (width - 1) / 2
    cy = (height - 1) / 2
    max_r = (cx ** 2 + cy ** 2) ** 0.5
    out = bytearray(rgba)
    for y in range(height):
        for x in range(width):
            dx = x - cx
            dy = y - cy
            r = ((dx * dx + dy * dy) ** 0.5) / max_r
            fade = smoothstep(inner, outer, r)
            if fade <= 0:
                continue
            i = (y * width + x) * 4
            out[i] = int(rgba[i] * (1 - fade) + BASE[0] * fade)
            out[i + 1] = int(rgba[i + 1] * (1 - fade) + BASE[1] * fade)
            out[i + 2] = int(rgba[i + 2] * (1 - fade) + BASE[2] * fade)
    return out


def main():
    src = os.path.join(ASSETS, "avatar_src.png")
    if not os.path.exists(src):
        sys.exit("нет assets/avatar_src.png")
    width, height, rgba = load_png_rgba(src)
    print("источник: %dx%d, яркость углов %s"
          % (width, height, [round(v) for v in corner_brightness(width, height, rgba)]))

    margin = int(min(width, height) * 0.045)
    inner_w = width - margin * 2
    inner_h = height - margin * 2
    cropped = bytearray(inner_w * inner_h * 4)
    for y in range(inner_h):
        src_row = ((y + margin) * width + margin) * 4
        cropped[y * inner_w * 4:(y + 1) * inner_w * 4] = rgba[src_row:src_row + inner_w * 4]

    scaled = box_resize(inner_w, inner_h, cropped, SIZE)
    smooth = blur(SIZE, SIZE, scaled, radius=1)
    final = vignette(SIZE, SIZE, smooth)
    print("после обработки: яркость углов %s"
          % [round(v) for v in corner_brightness(SIZE, SIZE, final)])

    write_png(os.path.join(ASSETS, "avatar.png"), SIZE, SIZE, final)
    print("assets/avatar.png обновлён")


if __name__ == "__main__":
    main()
