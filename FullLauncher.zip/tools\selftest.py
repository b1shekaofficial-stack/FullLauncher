"""Самопроверка ядра Full Launcher без запуска игры: python app.py --selftest"""

import json
import os
import shutil
import sys
import tempfile
import time

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from core import java as java_mod  # noqa: E402
from core import loaders as loaders_mod  # noqa: E402
from core import mc as mc_mod  # noqa: E402
from core import mods as mods_mod  # noqa: E402
from core import net  # noqa: E402

SAMPLE_VERSIONS = ["1.7.10", "1.12.2", "1.16.5", "1.20.1", "26.3"]
OK = "[ok]"
FAIL = "[!!]"


def head(title):
    print("\n=== %s ===" % title)


def check(condition, message):
    print(("%s %s" % (OK if condition else FAIL, message)))
    if not condition:
        check.errors += 1


check.errors = 0


def run(argv):
    root = os.path.join(tempfile.gettempdir(), "full-launcher-selftest")
    shutil.rmtree(root, ignore_errors=True)
    game = mc_mod.Game(root)
    game.ensure_dirs()

    head("Манифест версий")
    releases = game.releases()
    latest = game.manifest().get("latest", {}).get("release")
    check(len(releases) > 50, "релизов от 1.7.10: %d, последний %s" % (len(releases), latest))
    ids = [r["id"] for r in releases]
    check("1.7.10" in ids, "1.7.10 присутствует")
    check(latest in ids, "последний релиз присутствует")
    print("диапазон: %s -> %s" % (ids[-1], ids[0]))

    head("Слияние профилей и сборка команды")
    for vid in SAMPLE_VERSIONS:
        if vid not in ids:
            print("%s версия %s отсутствует в манифесте" % (FAIL, vid))
            check.errors += 1
            continue
        merged = game.merged(vid)
        libs = merged.get("libraries") or []
        mode = "arguments" if merged.get("arguments") else "minecraftArguments"
        args = None
        missing = [n for n in ("mainClass", "assetIndex") if not merged.get(n)]
        check(not missing, "%s: mainClass=%s libs=%d режим=%s%s"
              % (vid, merged.get("mainClass"), len(libs), mode,
                 (" нет: %s" % ",".join(missing)) if missing else ""))
        fake_java = os.path.join(root, "java", "bin", "javaw.exe")
        cmd = game.build_command(merged, {
            "java": fake_java,
            "nickname": "TestNick",
            "ram": 4096,
            "width": 925,
            "height": 530,
            "game_dir": root,
            "natives_dir": os.path.join(root, "versions", vid, "natives"),
            "classpath": "a.jar" + os.pathsep + "b.jar",
            "asset_index": (merged.get("assetIndex") or {}).get("id"),
            "log_conf": None,
            "version_name": vid,
        })
        unresolved = [tok for tok in cmd if "${" in tok]
        check(not unresolved, "%s: команда собрана (%d аргументов)%s"
              % (vid, len(cmd), (" не подставлено: %s" % unresolved) if unresolved else ""))
        check("TestNick" in " ".join(cmd), "%s: ник подставлен" % vid)
        check(any(tok == merged.get("mainClass") for tok in cmd), "%s: mainClass в команде" % vid)
        if "--debug" in argv:
            print("  " + " ".join(cmd[-14:]))

    head("Правила библиотек и нативы")
    merged = game.merged("1.7.10")
    windows_libs = [lib for lib in merged["libraries"] if mc_mod.is_allowed(lib.get("rules"))]
    natives = [lib for lib in windows_libs if mc_mod.native_classifier(lib)]
    check(len(windows_libs) > 20, "1.7.10: под Windows проходит %d библиотек" % len(windows_libs))
    check(len(natives) >= 2, "1.7.10: нативных библиотек %d" % len(natives))
    merged_new = game.merged("26.3")
    natives_new = [lib for lib in merged_new["libraries"]
                   if mc_mod.native_classifier(lib) or "natives" in (lib.get("name") or "")]
    check(bool(merged_new.get("arguments")), "26.3: современный формат arguments")
    check(len(natives_new) > 0, "26.3: нативных артефактов %d" % len(natives_new))

    head("Профили: классификаторы библиотек")
    parent = {"id": "base", "libraries": [{"name": "org.lwjgl:lwjgl:3.3.3"}]}
    child = {
        "id": "child",
        "inheritsFrom": "base",
        "libraries": [
            {"name": "net.minecraftforge:forge:1.0:universal",
             "downloads": {"artifact": {"path": "net/minecraftforge/forge/1.0/forge-1.0-universal.jar",
                                        "url": "https://example.invalid/universal.jar"}}},
            {"name": "net.minecraftforge:forge:1.0:client",
             "downloads": {"artifact": {"path": "net/minecraftforge/forge/1.0/forge-1.0-client.jar",
                                        "url": "", "sha1": "deadbeef"}}},
        ],
    }
    merged_probe = mc_mod.merge_versions(parent, child)
    probe_names = [lib["name"] for lib in merged_probe["libraries"]]
    check("net.minecraftforge:forge:1.0:universal" in probe_names
          and "net.minecraftforge:forge:1.0:client" in probe_names,
          "merge не схлопывает universal и client (разные классификаторы)")
    probe_entry = mc_mod.library_entry({
        "name": "net.minecraftforge:forge:1.0:client",
        "downloads": {"artifact": {"path": "net/minecraftforge/forge/1.0/forge-1.0-client.jar", "url": ""}},
    })
    check(probe_entry is not None and probe_entry["path"].endswith("forge-1.0-client.jar")
          and probe_entry["url"] == "",
          "библиотека с пустым url распознаётся по path (пропатченный client.jar)")

    head("Модлоадеры")
    try:
        fabric = loaders_mod.fabric_versions("1.20.1")
        check(len(fabric) > 0, "Fabric: %d сборок, последняя %s"
              % (len(fabric), loaders_mod.latest_fabric("1.20.1")))
    except Exception as exc:  # noqa: BLE001
        print("%s Fabric: %s" % (FAIL, exc))
        check.errors += 1
    try:
        forge = loaders_mod.forge_versions("1.20.1")
        check(len(forge) > 0, "Forge: %d сборок, последняя %s"
              % (len(forge), forge[-1] if forge else "—"))
    except Exception as exc:  # noqa: BLE001
        print("%s Forge: %s" % (FAIL, exc))
        check.errors += 1
    try:
        empty = loaders_mod.forge_versions("1.7.10")
        check(len(empty) > 0, "Forge 1.7.10: %d сборок" % len(empty))
    except Exception as exc:  # noqa: BLE001
        print("%s Forge 1.7.10: %s" % (FAIL, exc))

    try:
        opti = loaders_mod.optifine_versions(force=True)
        check(bool(opti), "OptiFine: список версий получен (%d), последняя %s"
              % (len(opti), opti[-1] if opti else "—"))
        if opti:
            ok_old, checked_old, _ = loaders_mod.optifine_support("1.20.1")
            ok_new, checked_new, latest = loaders_mod.optifine_support("26.3")
            check(checked_old and ok_old, "OptiFine доступен для 1.20.1")
            check(checked_new and not ok_new,
                  "OptiFine недоступен для 26.3 (последняя версия — %s)" % latest)
            check(latest == opti[-1], "последняя версия OptiFine отдаётся в подсказку")
            catalog = loaders_mod.optifine_catalog()
            check(bool(catalog), "каталог OptiFine: %d версий с именами файлов" % len(catalog))
            check("1.20.1" in catalog, "в каталоге есть файл под 1.20.1: %s" % catalog.get("1.20.1"))
            check(not str(catalog.get("1.20.1", "")).startswith("preview_"),
                  "для 1.20.1 выбран релизный файл, а не preview")
            check("26.3" not in catalog, "для 26.3 файла OptiFine в каталоге нет")
            check(loaders_mod.optifine_filename("1.20.1") == catalog.get("1.20.1"),
                  "optifine_filename() отдаёт тот же файл")
    except Exception as exc:  # noqa: BLE001
        print("%s OptiFine: %s" % (FAIL, exc))
        check.errors += 1

    head("Каталог модов (Modrinth)")
    try:
        res = mods_mod.search("forge", "1.20.1", "", page=1, per_page=5)
        check(bool(res.get("hits")), "Forge 1.20.1: %d модов, например %s"
              % (len(res.get("hits") or []), (res["hits"][0]["title"] if res.get("hits") else "—")))
        check("matching" in res and "gameVersion" in res,
              "в ответе есть счётчик подходящих под версию: %s из %s"
              % (res.get("matching"), len(res.get("hits") or [])))
        first = (res.get("hits") or [{}])[0]
        check(isinstance(first.get("versions"), list) and "supports" in first,
              "у мода есть список версий (%d шт.) и флаг supports=%s"
              % (len(first.get("versions") or []), first.get("supports")))
        res_f = mods_mod.search("fabric", "1.20.1", "", page=1, per_page=3)
        check(bool(res_f.get("hits")), "Fabric 1.20.1: %d модов" % len(res_f.get("hits") or []))
        old = mods_mod.search("forge", "1.7.10", "", page=1, per_page=10)
        check(bool(old.get("hits")), "Forge 1.7.10: каталог тоже отдаётся (%d модов)" % len(old.get("hits") or []))
        consistent = all(
            (not hit.get("versions"))
            or hit.get("supports") == ("1.7.10" in hit["versions"])
            or hit.get("verified")
            for hit in old.get("hits") or []
        )
        check(consistent, "флаг supports согласован со списком версий для 1.7.10")
        res_off = mods_mod.search("vanilla", "1.20.1")
        check(not res_off.get("available"), "vanilla: каталог помечен недоступным")

        first = mods_mod.search("forge", "26.3", "", page=1)
        check(len(first.get("hits") or []) == mods_mod.PER_PAGE,
              "пагинация: на странице %d модов (по %d)" % (len(first.get("hits") or []), mods_mod.PER_PAGE))
        check(first.get("pages") == 5 and first.get("total") == 100,
              "пагинация: %s страниц, всего %s модов" % (first.get("pages"), first.get("total")))
        last = mods_mod.search("forge", "26.3", "", page=5)
        check(len(last.get("hits") or []) == 16, "пагинация: последняя страница — 16 модов")
        beyond = mods_mod.search("forge", "26.3", "", page=6)
        check(not beyond.get("hits"), "пагинация: за пределами 100 модов пусто")

        sodium = mods_mod.availability("sodium", "26.3")
        check(sodium is not None and "fabric" in sodium and "forge" not in sodium,
              "API версий: sodium на 26.3 есть для %s и нет для forge" % sorted(sodium or []))
        modernfix = mods_mod.availability("modernfix", "26.3")
        check(modernfix == set(), "API версий: modernfix не имеет сборки на 26.3")

        jei = mods_mod.search("forge", "26.3", "jei", page=1, per_page=21)
        jei_hit = next((h for h in jei.get("hits") or [] if h.get("slug") == "jei"), None)
        check(jei_hit is not None and jei_hit.get("supports") is False,
              "Forge 26.3: JEI помечен недоступным (хотя поиск говорит, что версия есть)")
        check(jei_hit is not None and "forge" not in (jei_hit.get("availableLoaders") or []),
              "Forge 26.3: у JEI в списке доступных загрузчиков нет forge: %s"
              % (jei_hit.get("availableLoaders") if jei_hit else None))
        check(jei_hit is not None and all(l in ("forge", "fabric", "neoforge", "quilt")
                                          for l in jei_hit.get("availableLoaders") or []),
              "в подсказке только загрузчики модов (без datapack/paper)")
        try:
            mods_mod.install("jei", "forge", "26.3", os.path.join(root, "mods-check"))
            print("%s установка недоступного мода не должна была пройти" % FAIL)
            check.errors += 1
        except RuntimeError as exc:
            check("NeoForge" in str(exc) or "Fabric" in str(exc),
                  "ошибка установки объясняет, где сборка есть: %s" % exc)
    except Exception as exc:  # noqa: BLE001
        print("%s Modrinth: %s" % (FAIL, exc))
        check.errors += 1

    head("Шейдеры (Modrinth)")
    try:
        shader_kind = mods_mod.KIND_SHADER
        sh = mods_mod.search("optifine", "26.3", "", page=1, kind=shader_kind)
        check(sh.get("available") and bool(sh.get("hits")),
              "OptiFine 26.3: %d шейдеров" % len(sh.get("hits") or []))
        check(sh.get("kind") == shader_kind, "ответ помечен kind=shader")
        check(sh.get("total") == 100 and sh.get("pages") == 5,
              "шейдеры: %s позиций, %s страниц" % (sh.get("total"), sh.get("pages")))
        last_page = mods_mod.search("optifine", "26.3", "", page=5, kind=shader_kind)
        check(len(last_page.get("hits") or []) == 16, "шейдеры: на 5-й странице 16 позиций")
        first_shader = (sh.get("hits") or [{}])[0]
        check("supports" in first_shader and isinstance(first_shader.get("versions"), list),
              "у шейдера есть флаг supports и список версий (%d шт.)"
              % len(first_shader.get("versions") or []))
        check(mods_mod.search("forgeoptifine", "26.3", "", page=1, kind=shader_kind).get("available") is True,
              "Forge + OptiFine: каталог шейдеров доступен")
        check(mods_mod.search("forge", "26.3", "", page=1, kind=shader_kind).get("available") is False,
              "Forge без OptiFine: каталог шейдеров недоступен")
        check(mods_mod.search("fabric", "26.3", "", page=1, kind=shader_kind).get("available") is False,
              "Fabric: каталог шейдеров недоступен")
        shader_dir = os.path.join(root, "shaderpacks")
        os.makedirs(shader_dir, exist_ok=True)
        for name in ("pack.zip", "mod.jar"):
            with open(os.path.join(shader_dir, name), "wb") as f:
                f.write(b"x")
        listed = [item["file"] for item in mods_mod.installed(shader_dir, kind=shader_kind)]
        check(listed == ["pack.zip"], "в shaderpacks учитываются только .zip: %s" % listed)
    except Exception as exc:  # noqa: BLE001
        print("%s Шейдеры: %s" % (FAIL, exc))
        check.errors += 1

    head("Серверы: servers.dat (NBT)")
    from core import nbt as nbt_mod  # noqa: PLC0415
    servers_file = os.path.join(root, "servers.dat")
    if os.path.exists(servers_file):
        os.remove(servers_file)
    empty = nbt_mod.load(servers_file)
    check(empty == [], "пустой servers.dat читается как пустой список")
    first = nbt_mod.add_server(servers_file, "Hypixel", "mc.hypixel.net")
    second = nbt_mod.add_server(servers_file, "Тестовый сервер", "play.example.ru")
    again = nbt_mod.add_server(servers_file, "Hypixel", "mc.hypixel.net")
    check(first["added"] and second["added"], "два сервера добавлены")
    check(again["already"] and not again["added"], "повторное добавление не дублирует запись")
    loaded = nbt_mod.load(servers_file)
    check(len(loaded) == 2, "в файле ровно 2 сервера")
    check(loaded[0].get("ip") == "mc.hypixel.net", "адрес первого сохранён")
    check(loaded[1].get("name") == "Тестовый сервер", "кириллическое имя сохранено")
    check(loaded[0].get("acceptTextures") in (-1, 0, 1),
          "acceptTextures записан (%s)" % loaded[0].get("acceptTextures"))
    with open(servers_file, "rb") as f:
        payload = f.read()
    check(payload[:2] != b"\x1f\x8b", "новый servers.dat пишется простым NBT (как в 26.3)")

    plain_file = os.path.join(root, "servers_plain.dat")
    nbt_mod.save(plain_file, [{"name": "Mineblaze", "ip": "mc.mineblaze.net"}], compressed=False)
    check(nbt_mod.is_compressed(plain_file) is False, "формат plain определяется как не-gzip")
    check(nbt_mod.load(plain_file)[0]["ip"] == "mc.mineblaze.net", "plain-файл читается обратно")

    gz_file = os.path.join(root, "servers_gz.dat")
    nbt_mod.save(gz_file, [{"name": "Old", "ip": "play.example.ru"}], compressed=True)
    check(nbt_mod.is_compressed(gz_file) is True, "старый формат gzip поддерживается")
    check(nbt_mod.load(gz_file)[0]["name"] == "Old", "gzip-файл читается обратно")

    nbt_mod.add_server(plain_file, "Second", "play.second.ru", compressed=False)
    check(nbt_mod.is_compressed(plain_file) is False, "add_server не меняет формат файла")
    second_entry = [s for s in nbt_mod.load(plain_file) if s["ip"] == "play.second.ru"]
    check(bool(second_entry) and second_entry[0].get("hidden") == 0,
          "новая запись видимая (hidden=0), иначе Minecraft её не покажет")

    # Игра перезаписывает servers.dat своим скрытым quick-play входом —
    # лаунчер должен вернуть туда сервера, добавленные пользователем.
    nbt_mod.save(plain_file, [{"ip": "mc.MineBlaze.net", "name": "Minecraft Server", "hidden": 1}],
                 compressed=False)
    nbt_mod.add_server(plain_file, "Mineblaze", "mc.mineblaze.net", compressed=False)
    restored = nbt_mod.load(plain_file)
    mine = [s for s in restored if s["ip"].lower() == "mc.mineblaze.net"]
    check(bool(mine) and mine[0].get("hidden") == 0,
          "после перезаписи игрой сервер возвращается в список видимым")

    head("Java")
    javas = java_mod.detect(game)
    for item in javas:
        print("  Java %d · %s" % (item["version"], item["path"]))
    check(bool(javas), "найдено установленных Java: %d" % len(javas))
    pick8 = java_mod.pick(javas, 8)
    check(pick8 is not None, "для 1.7.10 подобрана Java 8: %s" % (pick8["version"] if pick8 else "нет"))
    print("  для 26.3 нужна Java %s (скачается автоматически, если нет)"
          % (game.merged("26.3").get("javaVersion") or {}))

    if "--install" in argv:
        target = argv[argv.index("--install") + 1] if len(argv) > argv.index("--install") + 1 else "1.7.10"
        head("Настоящая установка %s (проверка загрузок)" % target)
        progress = net.Progress()
        started = time.time()
        last = [0.0]

        def sink(snap):
            now = time.time()
            if now - last[0] < 1.0:
                return
            last[0] = now
            print("  %-46s %5.1f%%  %d/%d  %s"
                  % (snap["label"][:46], snap["percent"], snap["filesDone"],
                     snap["filesTotal"], net_progress_speed(snap)))

        progress.sink = sink
        result = game.install(target, progress)
        cmd = game.build_command(result["merged"], {
            "java": "javaw.exe", "nickname": "TestNick", "ram": 4096,
            "game_dir": root, "natives_dir": result["natives"],
            "classpath": game.classpath(result["merged"], result["jar"]),
            "asset_index": (result["merged"].get("assetIndex") or {}).get("id"),
            "log_conf": result["log"],
        })
        natives = os.listdir(result["natives"]) if os.path.isdir(result["natives"]) else []
        check(os.path.exists(result["jar"] or ""), "client.jar скачан")
        check(len(natives) > 0, "в natives распаковано %d файлов" % len(natives))
        check(any(os.sep + "lwjgl" in p for p in cmd), "LWJGL в classpath")
        print("  установка заняла %.1f c" % (time.time() - started))
        print("  команда: " + " ".join(cmd[:8]) + " …")
        with open(os.path.join(root, "selftest-command.txt"), "w", encoding="utf-8") as f:
            f.write(" ".join(cmd))
        print("  (игра НЕ запускалась, команда сохранена в %s)" % os.path.join(root, "selftest-command.txt"))

    head("Discord Rich Presence")
    from core import discord as discord_mod  # noqa: PLC0415
    frame = discord_mod.encode_frame(discord_mod.OP_FRAME, {"cmd": "SET_ACTIVITY", "n": 1})
    opcode, length = discord_mod.decode_header(frame[:8])
    payload = json.loads(frame[8:].decode("utf-8"))
    check(opcode == discord_mod.OP_FRAME and length == len(frame) - 8,
          "кадр IPC: заголовок 8 байт, длина %d, opcode %d" % (length, opcode))
    check(payload.get("cmd") == "SET_ACTIVITY", "payload кадра — корректный JSON")
    check(discord_mod.CLIENT_ID == "1564259805990756382",
          "client id приложения Discord задан: %s" % discord_mod.CLIENT_ID)
    activity = discord_mod.build_activity(
        "Играет в Minecraft", "26.3 · Forge", "Full Launcher", "26.3", 1700000000,
        buttons=[{"label": "Telegram", "url": "https://t.me/FullLauncher"}])
    check(activity["timestamps"]["start"] == 1700000000 * 1000, "timestamps в миллисекундах")
    check(activity["assets"]["large_text"] == "Full Launcher", "ассеты активности заполнены")
    check(bool(activity["buttons"] and activity["buttons"][0]["url"].startswith("https://")),
          "кнопка Telegram в активности")
    check(isinstance(discord_mod.find_pipe(), (str, type(None))),
          "поиск канала Discord не падает (найдено: %s)" % (discord_mod.find_pipe() or "нет"))
    rpc = discord_mod.DiscordRPC()
    status = rpc.status()
    check({"state", "detail", "connected"} <= set(status),
          "статус RPC отдаёт state/detail/connected: %s" % sorted(status))

    print("\nИтого проблем: %d" % check.errors)
    return 0 if check.errors == 0 else 1


def net_progress_speed(snap):
    speed = snap.get("speed") or 0
    return "%.1f МБ/с" % (speed / 1048576) if speed else "—"


if __name__ == "__main__":
    sys.exit(run(sys.argv[1:]))
